export const runtime = "nodejs";

import { readFileSync } from "node:fs";
import path from "node:path";
import { NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import { createClient } from "@/lib/supabase/server";
import { getSignedPhotoUrl } from "@/lib/supabase/storage";
import { verificarAcessoJogoBase } from "@/lib/auth/jogos-base-guard";
import { compararPorNumeroCamisaGoleiroPrimeiro } from "@/lib/futebol/ordem-posicao";
import { PresskitDocument, type AtletaPresskitItem } from "@/lib/pdf/presskit-document";
import type {
  AtletaRow,
  ComissaoTecnicaRow,
  ConvocacaoAtletaRow,
  ConvocacaoRow,
  ConvocacaoComissaoRow,
} from "@/lib/supabase/types";

/** Espelha `app/jogos/[id]/presskit/route.tsx` para o Futebol de Base. */
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  const supabase = createClient();

  const jogo = await verificarAcessoJogoBase(supabase, params.id);
  if (!jogo) {
    return new NextResponse("Jogo não encontrado.", { status: 404 });
  }

  const { data: convocacaoData } = await supabase
    .from("convocacoes")
    .select("*")
    .eq("jogo_id", params.id)
    .maybeSingle();

  if (!convocacaoData) {
    return new NextResponse(
      "Ainda não há convocação registrada para este jogo. Registre a convocação antes de gerar o presskit.",
      { status: 400 },
    );
  }
  const convocacao = convocacaoData as ConvocacaoRow;

  const [{ data: caData }, { data: ccData }, adversarioLogoUrl] = await Promise.all([
    supabase.from("convocacao_atletas").select("*, atleta:atletas(*)").eq("convocacao_id", convocacao.id),
    supabase
      .from("convocacao_comissao")
      .select("*, pessoa:comissao_tecnica(nome_completo)")
      .eq("convocacao_id", convocacao.id),
    getSignedPhotoUrl(supabase, jogo.adversario_logo_path),
  ]);

  const convocacaoAtletas = (caData ?? []) as (ConvocacaoAtletaRow & { atleta: AtletaRow })[];
  // Na Base o número da camisa é da CONVOCAÇÃO (esse jogo), não do cadastro do atleta — sobrepõe
  // `numero_camisa` do atleta pelo valor informado na convocação antes de ordenar/exibir, sem
  // precisar mexer no resto do PresskitDocument (que já lê `atleta.numero_camisa`). Titulares e
  // reservas saem por esse número, do menor pro maior (a numeração muda de jogo pra jogo, então
  // não faz sentido agrupar por posição como no Profissional — ver
  // 0059_convocacao_atleta_base_numero_camisa.sql), COM O GOLEIRO SEMPRE NA FRENTE: é regra do
  // Presskit e vale nas duas listas, senão o goleiro reserva de camisa 12 cai depois dos de linha.
  const comNumeroDaConvocacao = (c: ConvocacaoAtletaRow & { atleta: AtletaRow }): AtletaRow => ({
    ...c.atleta,
    numero_camisa: c.numero_camisa,
  });
  const atletasTitulares = convocacaoAtletas
    .filter((c) => c.status === "titular")
    .map(comNumeroDaConvocacao)
    .sort(compararPorNumeroCamisaGoleiroPrimeiro);
  const atletasReservas = convocacaoAtletas
    .filter((c) => c.status === "reserva")
    .map(comNumeroDaConvocacao)
    .sort(compararPorNumeroCamisaGoleiroPrimeiro);

  const comFoto = async (atletas: AtletaRow[]): Promise<AtletaPresskitItem[]> =>
    Promise.all(
      atletas.map(async (atleta) => ({
        atleta,
        fotoSrc: await getSignedPhotoUrl(supabase, atleta.foto_path),
      })),
    );
  const [titulares, reservas] = await Promise.all([comFoto(atletasTitulares), comFoto(atletasReservas)]);

  const comissaoNomes = ((ccData ?? []) as (ConvocacaoComissaoRow & {
    pessoa: Pick<ComissaoTecnicaRow, "nome_completo"> | null;
  })[])
    .map((c) => c.pessoa?.nome_completo)
    .filter((nome): nome is string => Boolean(nome));

  const juventusLogoPath = path.join(process.cwd(), "public/brand/juventus-escudo.png");
  const juventusLogoSrc = { data: readFileSync(juventusLogoPath), format: "png" as const };

  const buffer = await renderToBuffer(
    <PresskitDocument
      jogo={jogo}
      juventusLogoSrc={juventusLogoSrc}
      adversarioLogoSrc={adversarioLogoUrl}
      titulares={titulares}
      reservas={reservas}
      capitaoId={convocacao.capitao_atleta_id}
      comissaoNomes={comissaoNomes}
    />,
  );

  const nomeArquivo = `presskit-juventus-x-${jogo.adversario_nome
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")}-${jogo.data_jogo}.pdf`;

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="${nomeArquivo}"`,
    },
  });
}
