import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { SearchBar } from "@/components/search-bar";
import { DeleteButton } from "@/components/delete-button";
import { StaffAtivoButton } from "@/components/staff-ativo-button";
import { CadastroPublicoToggle } from "@/components/cadastro-publico-toggle";
import { createClient } from "@/lib/supabase/server";
import { getSignedPhotoUrl } from "@/lib/supabase/storage";
import { formatCPF } from "@/lib/validation/cpf";
import { formatTelefone } from "@/lib/validation/telefone";
import type {
  ConfiguracaoCadastroStaffBaseRow,
  StaffFuncaoCatalogoRow,
  StaffOperacionalComFuncaoRow,
} from "@/lib/supabase/types";
import { deleteStaffBase, alternarStaffBaseAtivo } from "./actions";
import { alternarCadastroPublicoBase } from "./cadastro-publico-actions";

function formatMoeda(valor: number | null): string {
  if (valor === null) return "—";
  return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function StaffRow({
  s,
  fotoUrl,
  opaco,
}: {
  s: StaffOperacionalComFuncaoRow;
  fotoUrl: string | null;
  opaco?: boolean;
}) {
  return (
    <tr className={opaco ? "opacity-75" : undefined}>
      <td className="px-4 py-3">
        {fotoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={fotoUrl} alt={s.nome_completo} className="h-10 w-10 rounded-full object-cover" />
        ) : (
          <div className="h-10 w-10 rounded-full bg-neutral-100" />
        )}
      </td>
      <td className="px-4 py-3 font-medium text-neutral-800">{s.nome_completo}</td>
      <td className="px-4 py-3">
        {s.terceirizada ? (
          <>
            <span className="rounded-full bg-neutral-100 px-2 py-0.5 text-xs font-medium text-neutral-600">
              Terceirizada
            </span>{" "}
            {s.funcao_terceirizada?.nome ?? "—"}
          </>
        ) : (
          s.funcao?.nome ?? "—"
        )}
      </td>
      <td className="px-4 py-3">{formatCPF(s.cpf)}</td>
      <td className="px-4 py-3">{s.telefone ? formatTelefone(s.telefone) : "—"}</td>
      <td className="px-4 py-3">{s.chave_pix ?? "—"}</td>
      <td className="px-4 py-3">{formatMoeda(s.valor_padrao_pagamento)}</td>
      <td className="px-4 py-3">
        <div className="flex flex-wrap justify-end gap-2">
          <Link href={`/base/staff-operacional/${s.id}`} className="btn-secondary">
            Editar
          </Link>
          <StaffAtivoButton action={alternarStaffBaseAtivo} id={s.id} ativo={s.ativo} />
          <DeleteButton action={deleteStaffBase} id={s.id} entityLabel="registro" />
        </div>
      </td>
    </tr>
  );
}

/** Espelha `app/staff-operacional/page.tsx` — lista única (sem categoria) do Futebol de Base. */
export default async function StaffOperacionalBasePage({
  searchParams,
}: {
  searchParams: { q?: string; funcaoId?: string };
}) {
  const q = searchParams.q?.trim() ?? "";
  const funcaoId = searchParams.funcaoId?.trim() ?? "";
  const supabase = createClient();

  let query = supabase
    .from("staff_operacional")
    .select(
      "*, funcao:staff_funcoes_catalogo!staff_operacional_funcao_id_fkey(nome), funcao_terceirizada:staff_funcoes_catalogo!staff_operacional_funcao_terceirizada_id_fkey(nome)",
    )
    .order("nome_completo", { ascending: true });
  if (q) query = query.ilike("nome_completo", `%${q}%`);
  if (funcaoId) query = query.eq("funcao_id", funcaoId);

  const [{ data, error }, { data: funcoesData }, { data: configData }] = await Promise.all([
    query,
    supabase.from("staff_funcoes_catalogo").select("*").order("nome", { ascending: true }),
    supabase.from("configuracoes_cadastro_staff_base").select("*").limit(1).maybeSingle(),
  ]);
  const staff = (data ?? []) as StaffOperacionalComFuncaoRow[];
  const funcoes = (funcoesData ?? []) as StaffFuncaoCatalogoRow[];
  const config = configData as ConfiguracaoCadastroStaffBaseRow | null;

  const fotoUrls = await Promise.all(staff.map((s) => getSignedPhotoUrl(supabase, s.foto_path)));
  const fotoPorId = new Map(staff.map((s, i) => [s.id, fotoUrls[i]]));

  const ativos = staff.filter((s) => s.ativo);
  const inativos = staff.filter((s) => !s.ativo);

  return (
    <AppShell departamento="futebol_base" breadcrumb="Staff Operacional">
      <div className="mt-3 flex flex-wrap justify-end gap-2">
        <a
          href={`/base/staff-operacional/export?q=${encodeURIComponent(q)}&funcaoId=${encodeURIComponent(funcaoId)}`}
          className="btn-secondary"
        >
          Exportar para Excel
        </a>
        <Link href="/staff-operacional/funcoes?voltar=base" className="btn-secondary">
          Gerenciar funções
        </Link>
        <Link href="/base/staff-operacional/novo" className="btn-primary">
          + Novo staff
        </Link>
      </div>

      {config ? (
        <div className="mt-4">
          <CadastroPublicoToggle
            id={config.id}
            ativo={config.cadastro_publico_ativo}
            linkPath="/cadastro-staff-base"
            action={alternarCadastroPublicoBase}
          />
        </div>
      ) : null}

      <div className="card mt-4 p-4">
        <SearchBar action="/base/staff-operacional" defaultValue={q} placeholder="Buscar por nome...">
          <div className="min-w-[180px]">
            <label htmlFor="funcaoId" className="field-label">
              Função/setor
            </label>
            <select id="funcaoId" name="funcaoId" defaultValue={funcaoId} className="field-input">
              <option value="">Todas</option>
              {funcoes.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.nome}
                </option>
              ))}
            </select>
          </div>
        </SearchBar>
      </div>

      {error ? (
        <p className="mt-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
          Não foi possível carregar os registros. Verifique a conexão com o Supabase.
        </p>
      ) : null}

      <div className="card tabela-rolavel mt-4">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="bg-neutral-50 text-neutral-600">
            <tr>
              <th className="px-4 py-3">Foto</th>
              <th className="px-4 py-3">Nome</th>
              <th className="px-4 py-3">Função/Setor</th>
              <th className="px-4 py-3">CPF</th>
              <th className="px-4 py-3">Telefone</th>
              <th className="px-4 py-3">Chave PIX</th>
              <th className="px-4 py-3">Valor padrão</th>
              <th className="px-4 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {ativos.map((s) => (
              <StaffRow key={s.id} s={s} fotoUrl={fotoPorId.get(s.id) ?? null} />
            ))}
            {ativos.length === 0 && !error ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-neutral-400">
                  Nenhum registro ativo encontrado.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {inativos.length > 0 ? (
        <details className="mt-6 rounded-lg border border-neutral-200">
          <summary className="cursor-pointer select-none px-4 py-3 text-sm font-medium text-neutral-600">
            Inativos ({inativos.length})
          </summary>
          <div className="tabela-rolavel border-t border-neutral-200 sm:border-x-0">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="bg-neutral-50 text-neutral-600">
                <tr>
                  <th className="px-4 py-3">Nome</th>
                  <th className="px-4 py-3">Função/Setor</th>
                  <th className="px-4 py-3">CPF</th>
                  <th className="px-4 py-3">Telefone</th>
                  <th className="px-4 py-3">Chave PIX</th>
                  <th className="px-4 py-3">Valor padrão</th>
                  <th className="px-4 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {inativos.map((s) => (
                  <StaffRow key={s.id} s={s} fotoUrl={fotoPorId.get(s.id) ?? null} opaco />
                ))}
              </tbody>
            </table>
          </div>
        </details>
      ) : null}
    </AppShell>
  );
}
