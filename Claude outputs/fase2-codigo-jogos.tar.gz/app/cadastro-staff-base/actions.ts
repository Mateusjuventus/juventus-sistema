"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { cadastroPublicoStaffSchema } from "@/lib/validation/schemas";
import { createAdminClient } from "@/lib/supabase/admin";
import { uploadFotoRedimensionada } from "@/lib/supabase/storage";
import { normalizeCPF } from "@/lib/validation/cpf";

/** Espelha `app/cadastro-staff/actions.ts` e confere `configuracoes_cadastro_staff_base`
 * (totalmente independente do fluxo do Profissional). Desde a unificação de Staff Operacional
 * (30/10/2026, ver 0155_unificacao_staff_operacional.sql) grava na MESMA tabela `staff_operacional`
 * do Profissional — lista única, sem categoria/departamento. */
export interface CadastroPublicoBaseFormState {
  error?: string;
  fieldErrors?: Record<string, string>;
  values?: Record<string, string | undefined>;
  success?: boolean;
}

function parseForm(formData: FormData) {
  const raw = {
    nomeCompleto: String(formData.get("nomeCompleto") ?? ""),
    rg: String(formData.get("rg") ?? ""),
    cpf: String(formData.get("cpf") ?? ""),
    dataNascimento: String(formData.get("dataNascimento") ?? ""),
    funcaoId: String(formData.get("funcaoId") ?? ""),
    telefone: String(formData.get("telefone") ?? ""),
    email: String(formData.get("email") ?? ""),
    cep: String(formData.get("cep") ?? ""),
    logradouro: String(formData.get("logradouro") ?? ""),
    numero: String(formData.get("numero") ?? ""),
    complemento: String(formData.get("complemento") ?? ""),
    bairro: String(formData.get("bairro") ?? ""),
    cidade: String(formData.get("cidade") ?? ""),
    uf: String(formData.get("uf") ?? ""),
    terceirizada: formData.get("terceirizada") === "on",
    funcaoTerceirizadaId: String(formData.get("funcaoTerceirizadaId") ?? ""),
    chavePix: String(formData.get("chavePix") ?? ""),
    chavePixTipo: String(formData.get("chavePixTipo") ?? ""),
  };

  const result = cadastroPublicoStaffSchema.safeParse(raw);
  return { raw: { ...raw, terceirizada: raw.terceirizada ? "on" : "" }, result };
}

function friendlyDbError(error: { code?: string; message: string }): string {
  if (error.code === "23505") {
    if (error.message.includes("cpf")) return "Já existe uma pessoa cadastrada com este CPF.";
    if (error.message.includes("rg")) return "Já existe uma pessoa cadastrada com este RG.";
    return "Já existe um cadastro com esses dados.";
  }
  return "Não foi possível enviar o cadastro. Tente novamente.";
}

async function uploadFotoIfPresent(
  admin: ReturnType<typeof createAdminClient>,
  formData: FormData,
  staffId: string,
): Promise<{ path?: string | null; error?: string }> {
  const file = formData.get("foto");
  if (!(file instanceof File) || file.size === 0) return {};

  const { path, error } = await uploadFotoRedimensionada(admin, file, "staff-operacional-base", staffId);

  if (error) return { error: "Não foi possível enviar a foto. O restante do cadastro não foi salvo." };
  return { path };
}

/**
 * Cadastro público de Staff Operacional do Futebol de Base (link sem login, ver
 * app/cadastro-staff-base/page.tsx). Roda inteiro com o cliente admin (service_role) — revalida a
 * checagem de "cadastro ativo" e a existência da função de novo, mesmo que a página já tenha
 * checado antes (a pessoa pode ter deixado a aba aberta depois que o cadastro foi desativado).
 */
export async function cadastrarStaffPublicoBase(
  _prevState: CadastroPublicoBaseFormState,
  formData: FormData,
): Promise<CadastroPublicoBaseFormState> {
  const { raw, result } = parseForm(formData);

  if (!result.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of result.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors, values: raw };
  }

  const admin = createAdminClient();

  const { data: configData } = await admin
    .from("configuracoes_cadastro_staff_base")
    .select("cadastro_publico_ativo")
    .limit(1)
    .maybeSingle();
  if (!configData?.cadastro_publico_ativo) {
    return {
      error: "O cadastro público está fechado no momento. Fale com o responsável do Futebol de Base.",
    };
  }

  const fotoFile = formData.get("foto");
  const temFotoNova = fotoFile instanceof File && fotoFile.size > 0;
  if (!temFotoNova) {
    return { fieldErrors: { foto: "A foto é obrigatória." }, values: raw };
  }

  const data = result.data;

  const { data: nomeExistente } = await admin
    .from("staff_operacional")
    .select("id")
    .ilike("nome_completo", data.nomeCompleto.trim())
    .limit(1);
  if ((nomeExistente?.length ?? 0) > 0) {
    return {
      fieldErrors: { nomeCompleto: "Já existe uma pessoa cadastrada com esse nome completo." },
      values: raw,
    };
  }

  // Terceirizada preenche só 1 campo de função na tela: usamos o mesmo id tanto pro funcao_id
  // "principal" (obrigatório no banco) quanto pro funcao_terceirizada_id.
  const funcaoIdParaValidar = (data.terceirizada ? data.funcaoTerceirizadaId : data.funcaoId) ?? "";
  const campoFuncaoComErro = data.terceirizada ? "funcaoTerceirizadaId" : "funcaoId";

  const { data: funcaoExistente } = await admin
    .from("staff_funcoes_catalogo")
    .select("id")
    .eq("id", funcaoIdParaValidar)
    .maybeSingle();
  if (!funcaoExistente) {
    return {
      fieldErrors: { [campoFuncaoComErro]: "Selecione uma função válida da lista." },
      values: raw,
    };
  }

  const id = randomUUID();
  const { error: uploadError, path: fotoPath } = await uploadFotoIfPresent(admin, formData, id);
  if (uploadError) return { error: uploadError, values: raw };

  const { error } = await admin.from("staff_operacional").insert({
    id,
    nome_completo: data.nomeCompleto,
    rg: data.rg,
    cpf: normalizeCPF(data.cpf),
    data_nascimento: data.dataNascimento,
    funcao_id: funcaoIdParaValidar,
    telefone: data.telefone || null,
    email: data.email || null,
    cep: data.cep || null,
    logradouro: data.logradouro || null,
    numero: data.numero || null,
    complemento: data.complemento || null,
    bairro: data.bairro || null,
    cidade: data.cidade || null,
    uf: data.uf || null,
    terceirizada: data.terceirizada,
    funcao_terceirizada_id: data.terceirizada ? funcaoIdParaValidar : null,
    chave_pix: data.terceirizada ? null : data.chavePix || null,
    chave_pix_tipo: data.terceirizada ? null : data.chavePixTipo || null,
    foto_path: fotoPath ?? null,
  });

  if (error) return { error: friendlyDbError(error), values: raw };

  revalidatePath("/base/staff-operacional");
  return { success: true };
}
