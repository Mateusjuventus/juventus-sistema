/**
 * Tipos das linhas das tabelas do Supabase, espelhando
 * supabase/migrations/0001_init.sql. Mantidos manualmente por enquanto;
 * podem ser substituídos por `supabase gen types typescript` no futuro.
 */

export type PeDominante = "destro" | "canhoto" | "ambidestro";

/** Status do atleta — ver docs/superpowers/specs/
 * 2026-10-01-departamento-medico-historico-status-design.md. Até 01/10/2026 estes mesmos 3
 * valores (com "suspenso" no lugar de "transicao") eram compartilhados com `AtletaBaseStatus`
 * (`AtletaBaseStatus = AtletaStatus | "dispensado"`); os dois tipos foram desacoplados nessa troca
 * — a Base continuou com "suspenso" (constraint própria em `atletas_base`, sem mudança), só o
 * Profissional ganhou "transicao" no lugar. Na unificação de 28/10/2026 (ver
 * docs/superpowers/specs/2026-10-28-unificacao-atletas-design.md e 0150_unificacao_atletas.sql,
 * passo 3), `atletas.status` passou a aceitar também "dispensado" (valor que só a Base usava) —
 * `status = 'suspenso'` foi convertido pra `'liberado'` na hora da migração de dados, então
 * "suspenso" nunca aparece aqui. */
export type AtletaStatus = "liberado" | "departamento_medico" | "transicao" | "dispensado";
export type TipoQuarto = "single" | "duplo" | "triplo";

/** Classificação fixa de posição, usada pra gerar a tag colorida (GOL/ZAG/LAT/MEI/ATA) na grade de
 * Convocação e agrupar o Campograma — ver `lib/futebol/categoria-posicao.ts`. Desde 25/08 não é
 * mais um campo do banco: é calculada a partir de `posicao` (`categoriaDaPosicao`). */
export type CategoriaPosicao = "goleiro" | "zagueiro" | "lateral" | "meia" | "atacante";

/** As 9 posições fixas do cadastro de Atleta (Profissional e Base) — ver
 * `docs/superpowers/specs/2026-08-25-atleta-contrato-posicao-cpf-design.md`. Mesmo valor gravado
 * em `AtletaRow.posicao`/`AtletaBaseRow.posicao` (texto legível, não um código) — o tipo aqui é só
 * usado como chave de `categoriaDaPosicao`, as colunas continuam tipadas como `string`. */
export type AtletaPosicao =
  | "Goleiro"
  | "Zagueiro"
  | "Lateral Direito"
  | "Lateral Esquerdo"
  | "Volante"
  | "Meia"
  | "Atacante"
  | "Ponta Direita"
  | "Ponta Esquerda";

/** Tipo de contrato do atleta. "Formação" é seu próprio valor aqui (ver migração 0097) — separado
 * de "Amador" desde que passou a existir na tela de Atletas como uma categoria própria, não mais
 * um sub-flag ("possui contrato de formação", que continua existindo só pra registros antigos de
 * "Amador" sem essa marcação). "Iniciação" era só do Futebol de Base (ver `AtletaBaseTipoContrato`)
 * até a unificação de 28/10/2026 liberar esse valor também em `atletas`/`atleta_contratos` (ver
 * 0150_unificacao_atletas.sql, passo 4), já que atletas de categorias mais jovens da Base agora
 * moram na mesma tabela. */
export type AtletaTipoContrato = "definitivo" | "emprestimo" | "amador" | "formacao" | "iniciacao";

/** Tamanho de uniforme (PP a XG) — pedido do Mateus em 2026-10-16, lista fixa de confecção
 * esportiva (ver docs/superpowers/specs/2026-10-16-atleta-dados-esportivos-contrato-design.md). */
export type TamanhoUniforme = "PP" | "P" | "M" | "G" | "GG" | "XG";

export interface AtletaRow {
  id: string;
  /** Unificação de Atletas (Profissional + Base), 28/10/2026 — ver docs/superpowers/specs/
   * 2026-10-28-unificacao-atletas-design.md e 0150_unificacao_atletas.sql. "profissional" é o
   * valor de toda linha que já existia antes da unificação; as 7 categorias de `CategoriaBase`
   * (ver linha ~234) são as que vieram de `atletas_base` (agora `atletas_base_old`, backup). Um
   * atleta nunca está em duas categorias ao mesmo tempo — valor escalar, não lista. */
  categoria: "profissional" | CategoriaBase;
  nome_completo: string;
  rg: string;
  cpf: string;
  data_nascimento: string;
  posicao: string;
  numero_camisa: number | null;
  numero_cbf: number | null;
  /** Deixou de ser editável pelo formulário em 2026-10-16 (pedido do Mateus: "pode remover... nº
   * FPF") — a coluna continua existindo só pra não perder o que já tinha cadastrado. */
  numero_fpf: number | null;
  pe_dominante: PeDominante | null;
  telefone: string | null;
  /** Pedido de 2026-10-16 (ver docs/superpowers/specs/2026-10-16-atleta-dados-pessoais-design.md). */
  email: string | null;
  /** Até a unificação de 28/10/2026 só existiam em `atletas_base` (atletas menores de idade) — ver
   * 0150_unificacao_atletas.sql, passo 2. Seguem sem exibição no formulário quando `categoria` é
   * "profissional". */
  email_pai: string | null;
  email_mae: string | null;
  cidade_natal: string | null;
  uf_natal: string | null;
  /** Texto livre antigo — o formulário de editar não grava mais nele desde a migração pro endereço
   * estruturado abaixo (ver 0099_atleta_endereco_estruturado.sql); continua só pra não sumir com
   * dados de cadastros antigos que só têm esse texto livre preenchido. */
  endereco_atual: string | null;
  /** Endereço estruturado, autopreenchido por CEP no formulário (ver `EnderecoFields`) — mesmo
   * padrão que `AtletaBaseRow` já tinha desde 0076_captacao_alojamento_base.sql, estendido pro
   * Futebol Profissional em 2026-09-10 (pedido do Mateus: "no profissional, deva ter todos os
   * dados do endereço"). */
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  /** Segundo endereço estruturado, independente do "Endereço atual" acima — representa onde o
   * atleta/família é de origem (pedido de 2026-10-16). Mesmo formato (CEP com autopreenchimento). */
  origem_cep: string | null;
  origem_logradouro: string | null;
  origem_numero: string | null;
  origem_complemento: string | null;
  origem_bairro: string | null;
  origem_cidade: string | null;
  origem_uf: string | null;
  data_inicio_clube: string | null;
  /** Distinto de `data_inicio_clube` — quando o vínculo de contrato começou, não quando o atleta
   * entrou no clube. Só cadastro interno, nunca vem do link público. Deixou de ser editável pelo
   * formulário em 2026-10-16 — ver `atleta_contratos`/aba "Contrato", que passa a ser dona dessa
   * informação daqui pra frente; esta coluna fica congelada no último valor antes da mudança (e é
   * sincronizada automaticamente pela função `criar_contrato_atleta` sempre que um novo contrato é
   * criado, só pra esta tela de resumo/filtros continuar precisa). */
  data_inicio_contrato: string | null;
  empresario_nome: string | null;
  /** Pedido de 2026-10-16 — telefone/e-mail do empresário (Dados esportivos). */
  empresario_telefone: string | null;
  empresario_email: string | null;
  /** Pedido de 2026-10-16 — lista fixa PP/P/M/G/GG/XG. */
  tamanho_uniforme: TamanhoUniforme | null;
  foto_path: string | null;
  status: AtletaStatus;
  /** Ver nota de `data_inicio_contrato` acima — mesma lógica (congelada, sincronizada pela função
   * de criar contrato). */
  data_fim_contrato: string | null;
  apelido: string | null;
  /** Ver nota de `data_inicio_contrato` acima — mesma lógica (congelada, sincronizada pela função
   * de criar contrato). */
  tipo_contrato: AtletaTipoContrato | null;
  possui_contrato_formacao: boolean;
  /** Mora no alojamento do clube — alimenta `/base/alojamento` (ver lib/futebol/alojamento.ts). Até
   * a unificação de 28/10/2026 só existia em `atletas_base`; o Mateus decidiu estender pro
   * Profissional também (ver 0150_unificacao_atletas.sql, passo 2). */
  alojado: boolean;
  /** Classificação G1/G2/G3 (ver `AtletaClassificacao`, linha ~254) — `null` quando o atleta ainda
   * não foi classificado. Mesma origem/decisão de `alojado` acima. */
  classificacao: AtletaClassificacao | null;
  /** Campos do Relatório de Dispensa (ver docs/superpowers/specs/
   * 2026-08-25-classificacao-dispensa-atleta-base-design.md, seção 3) — todos `null` até o
   * relatório ser gerado pela primeira vez. As 4 notas usam a mesma escala 3-9 do Parecer Final.
   * Até a unificação de 28/10/2026 só existiam em `atletas_base`. */
  dispensa_motivo: string | null;
  dispensa_nota_tecnica: number | null;
  dispensa_nota_fisica: number | null;
  dispensa_nota_tatica: number | null;
  dispensa_nota_comportamental: number | null;
  dispensa_data: string | null;
  dispensado_por: string | null;
  dispensado_em: string | null;
  /** Até a unificação de 28/10/2026 só existiam em `atletas_base` — ver 0150_unificacao_atletas.sql,
   * passo 2. */
  valor_ajuda_custo: number | null;
  agencia: string | null;
  mae_nome: string | null;
  mae_telefone: string | null;
  /** CPF da mãe/pai — pedido pelo Contrato de Formação (ver docs/superpowers/specs/
   * 2026-11-09-contrato-formacao-design.md): o modelo padrão do contrato exige o CPF dos
   * responsáveis, que não existia no cadastro até então. Preenchimento manual, sem
   * máscara/validação adicional (mesmo padrão do CPF do próprio atleta no formulário). */
  mae_cpf: string | null;
  pai_nome: string | null;
  pai_telefone: string | null;
  pai_cpf: string | null;
  /** Vigência do registro do atleta na CBF/FPF (BID) — dado do atleta, independente de qual
   * contrato está vigente ou arquivado (ver docs/superpowers/specs/2026-11-11-contrato-formacao-
   * fase2-design.md). Editável na tela de Contrato de Formação; não entra no texto do PDF. */
  vigencia_bid_inicio: string | null;
  vigencia_bid_fim: string | null;
  escola: string | null;
  /** Pedido de 25/08 (ver docs/superpowers/specs/2026-08-25-atleta-telefone-alergia-foto-design.md):
   * "Possui alergia a algum medicamento? Se sim, qual". `alergia_medicamento_qual` só é preenchido
   * quando `possui_alergia_medicamento` é `true`. */
  possui_alergia_medicamento: boolean;
  alergia_medicamento_qual: string | null;
  /** Ativo/inativo (ver 0098_atleta_ativo.sql) — independente do `status` esportivo (Liberado/
   * Suspenso/Departamento Médico). Mesmo padrão de Staff Operacional/Veículos/Hotéis: em vez de
   * excluir o cadastro, ele fica marcado como inativo e some das listas/exportações por padrão
   * (`ativo` sempre `true` até alguém desativar manualmente pelo botão "Desativar" na página do
   * atleta). Desde 05/11/2026 essa troca pede motivo/observação e fica registrada em
   * `atletas_ativo_historico` (ver `AtletaAtivoHistoricoRow` abaixo e `lib/futebol/ativo-
   * historico.ts`) — este campo continua sendo o denormalizado que o resto do sistema lê. */
  ativo: boolean;
  /** Dados de Pagamento (ver docs/superpowers/specs/2026-11-04-atletas-desativacao-transicao-
   * pagamento-design.md) — campo do cadastro, sem vínculo direto com `atleta_contratos`. Desde
   * 14/11/2026, PF e PJ são seções independentes (podem estar as duas marcadas) — substituiu o
   * antigo `tipo_pagamento` (enum "pf"|"pj", um ou outro). `pf_*` só fazem sentido quando
   * `recebe_como_pf` é `true`; `empresa_imagem_*` só fazem sentido quando `recebe_como_pj` é
   * `true`. */
  recebe_como_pf: boolean;
  pf_chave_pix_tipo: string | null;
  pf_chave_pix: string | null;
  pf_banco: string | null;
  pf_agencia: string | null;
  pf_conta: string | null;
  recebe_como_pj: boolean;
  empresa_imagem_nome: string | null;
  empresa_imagem_cnpj: string | null;
  empresa_imagem_chave_pix_tipo: string | null;
  empresa_imagem_chave_pix: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Documento anexado ao atleta (aba "Documentação" do perfil) — só nome livre + arquivo, sem
 * categoria fixa nem data de validade (ver docs/superpowers/specs/2026-08-04-estatisticas-atleta-design.md).
 * Pra corrigir um documento errado, exclui e reenvia — não tem edição de nome depois de enviado. */
export interface AtletaDocumentoRow {
  id: string;
  atleta_id: string;
  nome: string;
  arquivo_path: string;
  created_by: string | null;
  created_at: string;
}

/** Contato de emergência do atleta (Dados Pessoais) — lista, pode haver mais de um por atleta (ver
 * docs/superpowers/specs/2026-10-16-atleta-dados-pessoais-design.md). */
export interface AtletaContatoEmergenciaRow {
  id: string;
  atleta_id: string;
  nome: string;
  parentesco: string | null;
  contato: string | null;
  created_at: string;
}

/** Espelha `AtletaContatoEmergenciaRow`, mas pra `atletas_base`. */
export interface AtletaBaseContatoEmergenciaRow {
  id: string;
  atleta_id: string;
  nome: string;
  parentesco: string | null;
  contato: string | null;
  created_at: string;
}

/** Anotação do histórico do atleta (aba "Anotações") — texto livre, nunca editada depois de criada;
 * só apagada por quem é "master" (ver `removerAnotacao` em `app/atletas/actions.ts`). Na Base, a
 * tela mistura isto com uma entrada "virtual" de Dispensa (montada a partir dos campos `dispensa_*`
 * de `AtletaBaseRow`, não gravada aqui) — ver docs/superpowers/specs/
 * 2026-10-27-ficha-atleta-dossie-anotacoes-design.md. */
export interface AtletaAnotacaoRow {
  id: string;
  atleta_id: string;
  texto: string;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Espelha `AtletaAnotacaoRow`, mas pra `atletas_base` — também escrita pelo Treinador (só cria,
 * nunca apaga). */
export interface AtletaBaseAnotacaoRow {
  id: string;
  atleta_id: string;
  texto: string;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Um contrato do atleta (aba "Contrato" do perfil) — histórico completo, no máximo um `vigente`
 * por atleta (garantido por índice único parcial no banco). Ver docs/superpowers/specs/
 * 2026-10-16-atleta-dados-esportivos-contrato-design.md. */
export interface AtletaContratoRow {
  id: string;
  atleta_id: string;
  vigente: boolean;
  tipo_contrato: AtletaTipoContrato;
  /** Só preenchido quando `tipo_contrato` é "emprestimo". */
  clube_origem: string | null;
  vigencia_inicio: string | null;
  vigencia_fim: string | null;
  salario_ctps: number;
  direito_imagem: number;
  bonificacao: number;
  auxilio_moradia: number;
  outros: number;
  /** Direitos econômicos (até 3 partes, em %) — ver 0158_atleta_contrato_extensoes.sql. Todos
   * opcionais e independentes entre si; a soma dos 3 não pode passar de 100 (checada no banco),
   * mas pode ficar abaixo — nem sempre as partes já estão 100% negociadas. */
  direito_economico_juventus_pct: number | null;
  direito_economico_atleta_pct: number | null;
  /** Nome do clube co-detentor — só faz sentido junto de `direito_economico_terceiro_pct`. */
  direito_economico_terceiro_nome: string | null;
  direito_economico_terceiro_pct: number | null;
  /** Valor mensal da bolsa de aprendizagem (R$) — só preenchido quando `tipo_contrato` é
   * "formacao" (ver docs/superpowers/specs/2026-11-09-contrato-formacao-design.md); as 5 rubricas
   * acima não se aplicam a esse tipo (ver `contratoTemRemuneracaoFormal`). Preenchido manualmente
   * ao lançar o contrato — alimenta o PDF do Contrato de Formação. */
  bolsa_aprendizagem: number;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
  encerrado_em: string | null;
}

/** Rubrica de remuneração do contrato — as mesmas 5 colunas de valor de `AtletaContratoRow`,
 * como union type pra identificar qual delas uma evolução salarial afeta (ver
 * `AtletaContratoEvolucaoSalarialRow` abaixo). */
export type RubricaContrato = "salario_ctps" | "direito_imagem" | "bonificacao" | "auxilio_moradia" | "outros";

/** Agenda de mudanças futuras de uma rubrica dentro de um contrato — "a partir de tal data, tal
 * rubrica passa a valer R$ X" (ver 0158_atleta_contrato_extensoes.sql e docs/superpowers/specs/
 * 2026-11-04-contrato-atleta-extensoes-design.md). Presa ao `contrato_id`: só é editável enquanto
 * esse contrato é o vigente (sem sentido editar a evolução de um contrato que já é histórico),
 * mas continua visível (só leitura) quando o contrato vira histórico. */
export interface AtletaContratoEvolucaoSalarialRow {
  id: string;
  contrato_id: string;
  rubrica: RubricaContrato;
  data_vigencia: string;
  novo_valor: number;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Métrica de um Gatilho (bônus por meta de desempenho) — ver `AtletaContratoGatilhoRow` abaixo.
 * As 4 primeiras (`pct_*`) são percentuais sobre o total de jogos do universo filtrado; as 2
 * últimas (`total_*`) são contagem absoluta. */
export type MetricaGatilhoContrato =
  | "pct_convocado"
  | "pct_titular"
  | "pct_mais_um_tempo"
  | "pct_jogo_completo"
  | "total_gols"
  | "total_assistencias";

/** Gatilho (bônus por meta de desempenho) dentro de um contrato — ver 0159_atleta_contrato_
 * gatilhos.sql e docs/superpowers/specs/2026-11-04-contrato-atleta-gatilhos-design.md. `limiar` é
 * percentual (0-100) pras métricas `pct_*`, contagem absoluta pras `total_*`. `cumprida_em` é
 * `null` enquanto o bônus não foi confirmado (o progresso é sempre calculado ao vivo, nunca lido
 * daqui) — setado uma única vez, pelo botão "Confirmar bônus", e nunca desfeito automaticamente.
 * Preso ao `contrato_id`, mesmo princípio de `AtletaContratoEvolucaoSalarialRow`: só editável
 * enquanto esse contrato é o vigente. As Competições que entram no universo de jogos deste gatilho
 * ficam em `atleta_contrato_gatilho_competicoes` (tabela de junção, buscada à parte). */
export interface AtletaContratoGatilhoRow {
  id: string;
  contrato_id: string;
  metrica: MetricaGatilhoContrato;
  limiar: number;
  valor_bonus: number;
  incluir_sem_competicao: boolean;
  cumprida_em: string | null;
  confirmada_por_perfil_id: string | null;
  confirmada_por_nome: string | null;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Linha de junção `atleta_contrato_gatilho_competicoes` — sem FK pra `competicoes`/
 * `competicoes_base` de propósito (ver a migração); `competicao_id` aponta pra uma ou outra
 * dependendo do departamento do atleta. */
export interface AtletaContratoGatilhoCompeticaoRow {
  gatilho_id: string;
  competicao_id: string;
}

/** Espelha `AtletaContratoRow`, mas pra `atletas_base` (`tipo_contrato` aceita também
 * "iniciacao"). */
export interface AtletaBaseContratoRow {
  id: string;
  atleta_id: string;
  vigente: boolean;
  tipo_contrato: AtletaBaseTipoContrato;
  clube_origem: string | null;
  vigencia_inicio: string | null;
  vigencia_fim: string | null;
  salario_ctps: number;
  direito_imagem: number;
  bonificacao: number;
  auxilio_moradia: number;
  outros: number;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
  encerrado_em: string | null;
}

/** Categorias de idade do Futebol de Base (Sub20 a Sub11) — ver `lib/auth/categorias-base.ts`. */
export type CategoriaBase = "sub20" | "sub17" | "sub15" | "sub14" | "sub13" | "sub12" | "sub11";

/** Tipo de contrato do atleta no Futebol de Base — mesmas opções de `AtletaTipoContrato` (incluindo
 * "formacao"), mais "Iniciação" (categorias mais jovens, sem vínculo formal ainda). */
export type AtletaBaseTipoContrato = "definitivo" | "emprestimo" | "amador" | "formacao" | "iniciacao";

/** Status do atleta no Futebol de Base (ver docs/superpowers/specs/
 * 2026-08-25-classificacao-dispensa-atleta-base-design.md e
 * 0087_atleta_base_classificacao_dispensa.sql) — tipo próprio, independente de `AtletaStatus`
 * desde 01/10/2026 (ver docs/superpowers/specs/2026-10-01-departamento-medico-historico-status-
 * design.md): a Base continua com "suspenso" e sem "transicao", então os dois nunca mais devem
 * derivar um do outro. */
export type AtletaBaseStatus = "liberado" | "suspenso" | "departamento_medico" | "dispensado";

/** Classificação G1/G2/G3 do atleta da Base — rótulo livre, sem significado fixo documentado no
 * sistema (cabe ao clube decidir o que cada grupo representa); o sistema só guarda e mostra a cor
 * de borda (verde/amarelo/laranja). Opcional — nem todo atleta precisa estar classificado.
 * "dispensa" ("Dispensa (pendente)", ver docs/superpowers/specs/
 * 2026-09-02-campograma-edicao-rapida-design.md) é um 4º valor — sinalizador de saída em avaliação,
 * NÃO muda `AtletaBaseStatus`; só o Relatório de Dispensa formal muda o status pra "dispensado". */
export type AtletaClassificacao = "g1" | "g2" | "g3" | "dispensa";

/** Espelha `AtletaRow`, mas para o departamento Futebol de Base — tabela `atletas_base`, totalmente
 * independente de `atletas` (ver docs/superpowers/specs/2026-07-20-futebol-de-base-design.md). */
export interface AtletaBaseRow {
  id: string;
  categoria: CategoriaBase;
  nome_completo: string;
  /** Opcional desde a Captação/Avaliação (ver 0076_captacao_alojamento_base.sql) — quem é
   * aprovado direto de lá normalmente ainda não tem RG/CPF à mão; o Mateus completa depois. */
  rg: string | null;
  cpf: string | null;
  /** Opcional desde a inclusão rápida pelo Campograma (ver docs/superpowers/specs/
   * 2026-09-02-campograma-edicao-rapida-design.md, seção 4) — nesse fluxo o atleta é criado só com
   * nome e posição; `null` aqui, junto de `rg`/`cpf` também nulos, é o que marca "Cadastro
   * incompleto" nas listagens/página do atleta. */
  data_nascimento: string | null;
  posicao: string;
  numero_camisa: number | null;
  numero_cbf: number | null;
  /** Deixou de ser editável pelo formulário em 2026-10-16 — ver nota equivalente em `AtletaRow`. */
  numero_fpf: number | null;
  pe_dominante: PeDominante | null;
  telefone: string | null;
  /** Pedido de 2026-10-16, junto com `email_pai`/`email_mae` abaixo (ver docs/superpowers/specs/
   * 2026-10-16-atleta-dados-pessoais-design.md) — só na Base, por serem atletas menores de idade. */
  email: string | null;
  email_pai: string | null;
  email_mae: string | null;
  cidade_natal: string | null;
  uf_natal: string | null;
  /** Texto livre antigo — os cadastros novos usam os campos estruturados abaixo (cep/logradouro/
   * etc.), que alimentam o autopreenchimento por CEP. Mantido só pra não perder o que já tinha. */
  endereco_atual: string | null;
  /** Segundo endereço estruturado — ver nota equivalente em `AtletaRow`. */
  origem_cep: string | null;
  origem_logradouro: string | null;
  origem_numero: string | null;
  origem_complemento: string | null;
  origem_bairro: string | null;
  origem_cidade: string | null;
  origem_uf: string | null;
  data_inicio_clube: string | null;
  /** Distinto de `data_inicio_clube` — quando o vínculo de contrato começou, não quando o atleta
   * entrou no clube. Só cadastro interno, nunca vem do link público. Ver nota de congelamento/
   * sincronização equivalente em `AtletaRow` — mesma lógica aqui. */
  data_inicio_contrato: string | null;
  empresario_nome: string | null;
  empresario_email: string | null;
  tamanho_uniforme: TamanhoUniforme | null;
  foto_path: string | null;
  status: AtletaBaseStatus;
  data_fim_contrato: string | null;
  apelido: string | null;
  tipo_contrato: AtletaBaseTipoContrato | null;
  possui_contrato_formacao: boolean;
  /** Mora no alojamento do clube — alimenta `/base/alojamento` (ver lib/futebol/alojamento.ts). */
  alojado: boolean;
  /** Classificação G1/G2/G3 (ver `AtletaClassificacao`) — `null` quando o atleta ainda não foi
   * classificado. */
  classificacao: AtletaClassificacao | null;
  /** Campos do Relatório de Dispensa (ver docs/superpowers/specs/
   * 2026-08-25-classificacao-dispensa-atleta-base-design.md, seção 3) — todos `null` até o
   * relatório ser gerado pela primeira vez. As 4 notas usam a mesma escala 3-9 do Parecer Final. */
  dispensa_motivo: string | null;
  dispensa_nota_tecnica: number | null;
  dispensa_nota_fisica: number | null;
  dispensa_nota_tatica: number | null;
  dispensa_nota_comportamental: number | null;
  dispensa_data: string | null;
  dispensado_por: string | null;
  dispensado_em: string | null;
  valor_ajuda_custo: number | null;
  agencia: string | null;
  empresario_telefone: string | null;
  mae_nome: string | null;
  mae_telefone: string | null;
  pai_nome: string | null;
  pai_telefone: string | null;
  escola: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  /** Pedido de 25/08 (ver docs/superpowers/specs/2026-08-25-atleta-telefone-alergia-foto-design.md):
   * "Possui alergia a algum medicamento? Se sim, qual". `alergia_medicamento_qual` só é preenchido
   * quando `possui_alergia_medicamento` é `true`. */
  possui_alergia_medicamento: boolean;
  alergia_medicamento_qual: string | null;
  /** Ativo/inativo (ver 0098_atleta_ativo.sql) — independente do `status` esportivo, e diferente de
   * "dispensado" (que é ligado ao Relatório de Dispensa formal). Mesmo padrão de Staff Operacional/
   * Veículos/Hotéis: em vez de excluir o cadastro, ele fica marcado como inativo e some das listas/
   * exportações por padrão. */
  ativo: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Espelha `AtletaDocumentoRow`, mas para o Futebol de Base — tabela `atleta_documentos_base`. */
export interface AtletaDocumentoBaseRow {
  id: string;
  atleta_id: string;
  nome: string;
  arquivo_path: string;
  created_by: string | null;
  created_at: string;
}

/** Tipo de contrato da Comissão Técnica/Diretoria (Profissional e Base) — ver
 * `COMISSAO_TECNICA_TIPO_CONTRATO_OPTIONS` em `lib/validation/schemas.ts`. */
export type ComissaoTecnicaTipoContrato = "clt" | "pj" | "sem_contrato";

export interface ComissaoTecnicaRow {
  id: string;
  /** Unificação da Comissão Técnica (Profissional + Base), 28/10/2026 — ver docs/superpowers/specs/
   * 2026-10-28-unificacao-comissao-tecnica-design.md e 0149_unificacao_comissao_tecnica.sql. Uma
   * pessoa pode atuar em mais de uma categoria (ex.: mesmo coordenador no Profissional e no Sub-11)
   * — por isso é array, nunca vazio ("profissional" é o valor de toda linha que já existia antes
   * da unificação). Diferente de `AtletaRow.categoria`, que é escalar. */
  categorias: Array<"profissional" | CategoriaBase>;
  nome_completo: string;
  rg: string;
  cpf: string;
  data_nascimento: string;
  funcao: string;
  telefone: string | null;
  email: string | null;
  foto_path: string | null;
  /** Não é mais exibido/editado em lugar nenhum do sistema (cadastro ou Relatórios Avulsos) desde
   * 25/08 — coluna mantida só pelo histórico de quem já preenchia (ver a spec de 25/08). */
  tipo_quarto_preferido: TipoQuarto | null;
  apelido: string | null;
  tipo_contrato: ComissaoTecnicaTipoContrato | null;
  data_inicio: string | null;
  /** Salário mensal — mesmo campo que já existia em `ComissaoTecnicaBaseRow` (ver
   * docs/superpowers/specs/2026-08-19-financeiro-base-design.md), agora também no Profissional. */
  valor_salario: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Espelha `ComissaoTecnicaRow`, mas para o Futebol de Base — tabela `comissao_tecnica_base`, mais
 * `categoria` (ver `lib/auth/categorias-base.ts`). */
export interface ComissaoTecnicaBaseRow {
  id: string;
  /** Uma pessoa pode atuar em mais de uma categoria (ex.: mesmo treinador no Sub-11 e no Sub-12) —
   * ver docs/superpowers/specs/2026-08-19-comissao-tecnica-multi-categoria-design.md. Sempre pelo
   * menos 1 item. */
  categorias: CategoriaBase[];
  nome_completo: string;
  rg: string;
  cpf: string;
  data_nascimento: string;
  funcao: string;
  telefone: string | null;
  email: string | null;
  foto_path: string | null;
  /** Não é mais exibido/editado em lugar nenhum do sistema (cadastro ou Relatórios Avulsos) desde
   * 25/08 — coluna mantida só pelo histórico de quem já preenchia (ver a spec de 25/08). */
  tipo_quarto_preferido: TipoQuarto | null;
  apelido: string | null;
  tipo_contrato: ComissaoTecnicaTipoContrato | null;
  data_inicio: string | null;
  /** Salário mensal — snapshot do valor atual, não um lançamento recorrente (ver
   * docs/superpowers/specs/2026-08-19-financeiro-base-design.md). `null` até o Mateus preencher. */
  valor_salario: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Uma caixa do Organograma do Futebol de Base (ver
 * docs/superpowers/specs/2026-08-23-organograma-base-design.md). Com `comissao_tecnica_base_id`
 * preenchido, nome/função exibidos vêm sempre do cadastro vinculado — `nome`/`cargo` aqui só valem
 * pra caixa sem pessoa vinculada (Presidente, Diretor, vaga em aberto). */
export interface OrganogramaBaseRow {
  id: string;
  comissao_tecnica_base_id: string | null;
  nome: string | null;
  cargo: string | null;
  grupo: string | null;
  /** Rótulo da linha (ex. "Comissão Sub20") — cruza com `grupo` (coluna) pra formar uma grade;
   * caixas com a mesma `linha` alinham na mesma altura em colunas diferentes. Só faz sentido junto
   * com `grupo` preenchido. */
  linha: string | null;
  reporta_para: string | null;
  ordem: number;
  pos_x: number | null;
  pos_y: number | null;
  /** `true` só quando `pos_x`/`pos_y` veio de um arrasto manual — o recálculo automático de
   * posições (`ajustarPosicoesAutomaticas`) nunca toca numa caixa com isso marcado, ver spec de
   * 27/08. */
  pos_manual: boolean;
  created_at: string;
  updated_at: string;
}

/** Qual caixa de liderança (supervisor) cada comissão/departamento (`linha`) do Organograma da Base
 * reporta pra — ver docs/superpowers/specs/2026-09-15-organograma-cartoes-por-comissao-design.md.
 * Uma linha por valor de `linha` usado em `OrganogramaBaseRow`; `reporta_para` nulo até alguém
 * escolher pela tela (a comissão continua aparecendo, só cai num grupo "sem supervisor definido"). */
export interface OrganogramaBaseLinhaRow {
  linha: string;
  reporta_para: string | null;
  // Posição arrastada pelo usuário pro cartão inteiro dessa linha; null = layout automático (mesmo
  // princípio de `organograma_base.pos_x/pos_y` pra uma caixa de liderança — ver migration 0109).
  pos_x: number | null;
  pos_y: number | null;
  pos_manual: boolean;
  updated_at: string;
}

export interface StaffFuncaoCatalogoRow {
  id: string;
  nome: string;
  created_at: string;
}

export type StaffChavePixTipo = "cpf" | "cnpj" | "email" | "telefone" | "aleatoria";

export interface StaffOperacionalRow {
  id: string;
  nome_completo: string;
  rg: string;
  cpf: string;
  data_nascimento: string;
  funcao_id: string;
  telefone: string | null;
  /** Serviço prestado por empresa terceirizada — quando true, chave_pix/chave_pix_tipo ficam
   * sempre nulos (o pagamento não é direto à pessoa) e funcao_terceirizada_id é obrigatório. */
  terceirizada: boolean;
  funcao_terceirizada_id: string | null;
  chave_pix: string | null;
  chave_pix_tipo: StaffChavePixTipo | null;
  valor_padrao_pagamento: number | null;
  email: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  ativo: boolean;
  foto_path: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Linha de staff_operacional já com a função (e a função da terceirizada, quando houver) embutidas
 * via join (`funcao:staff_funcoes_catalogo(nome)`, `funcao_terceirizada:staff_funcoes_catalogo(nome)`). */
export interface StaffOperacionalComFuncaoRow extends StaffOperacionalRow {
  funcao: { nome: string } | null;
  funcao_terceirizada: { nome: string } | null;
}

/** Espelha `StaffOperacionalRow`, mas para o Futebol de Base — tabela `staff_operacional_base`, sem
 * categoria (lista única, compartilhada — ver a spec). `funcao_id` referencia o mesmo catálogo
 * compartilhado `staff_funcoes_catalogo`. */
export interface StaffOperacionalBaseRow {
  id: string;
  nome_completo: string;
  rg: string;
  cpf: string;
  data_nascimento: string;
  funcao_id: string;
  telefone: string | null;
  terceirizada: boolean;
  funcao_terceirizada_id: string | null;
  chave_pix: string | null;
  chave_pix_tipo: StaffChavePixTipo | null;
  valor_padrao_pagamento: number | null;
  email: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  ativo: boolean;
  foto_path: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface StaffOperacionalBaseComFuncaoRow extends StaffOperacionalBaseRow {
  funcao: { nome: string } | null;
  funcao_terceirizada: { nome: string } | null;
}

export interface JogoRow {
  id: string;
  /** Unificação de Jogos/Convocação, 30/10/2026 — ver docs/superpowers/specs/
   * 2026-10-29-unificacao-jogos-design.md e 0157_unificacao_jogos.sql. Mesmo formato de
   * `AtletaRow.categoria`/`ComissaoTecnicaRow.categorias` ("profissional" + as 7 de `CategoriaBase`)
   * — um jogo é sempre de uma categoria só, nunca duas ao mesmo tempo (escalar, não lista). */
  categoria: "profissional" | CategoriaBase;
  competicao: string;
  rodada_fase: string | null;
  adversario_nome: string;
  adversario_logo_path: string | null;
  data_jogo: string;
  horario: string | null;
  local_estadio: string | null;
  endereco: string | null;
  mandante: boolean;
  gols_pro: number | null;
  gols_contra: number | null;
  concentracao_data: string | null;
  concentracao_regras: string;
  dia_jogo_liberacao: string | null;
  /** Link do PDF da súmula oficial da FPF, gravado quando a importação por link (aba Súmula) é
   * confirmada — ver docs/superpowers/specs/2026-08-04-integracao-fpf-design.md,
   * app/jogos/[id]/sumula/importar-actions.ts e app/competicoes/[id]/resultados/page.tsx. Opcional
   * (em vez de sempre presente) só pra continuar compatível com os componentes de PDF
   * compartilhados (`lib/pdf/*`), que tipam `jogo` como `JogoRow` mesmo quando recebem um
   * `JogoBaseRow` de verdade (mesmo formato estrutural, ver comentário desses arquivos) — nenhum
   * desses componentes lê esse campo. */
  fpf_link_sumula?: string | null;
  /** Pênaltis marcados pelo Juventus/adversário na disputa (quando o jogo foi a pênaltis) — até a
   * unificação de 30/10/2026 só existia em `JogoBaseRow` (ver 0146_sumula_pdf_terceiro_tempo_
   * penaltis.sql). Null = não houve disputa de pênaltis ou ainda não informado. */
  penaltis_pro: number | null;
  penaltis_contra: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export type ProgramacaoTipo = "concentracao" | "dia_jogo";

export interface JogoProgramacaoItemRow {
  id: string;
  jogo_id: string;
  tipo: ProgramacaoTipo;
  ordem: number;
  horario: string;
  atividade: string;
  local: string;
  eh_confronto: boolean;
  created_at: string;
}

export type ConvocacaoAtletaStatus = "titular" | "reserva";

export interface IngressoCargaRow {
  id: string;
  jogo_id: string;
  quantidade: number;
  data: string;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface IngressoSolicitacaoRow {
  id: string;
  jogo_id: string;
  nome_solicitante: string;
  quantidade_solicitada: number;
  quantidade_atendida: number;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ConvocacaoRow {
  id: string;
  jogo_id: string;
  capitao_atleta_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ConvocacaoAtletaRow {
  convocacao_id: string;
  atleta_id: string;
  status: ConvocacaoAtletaStatus;
  /** Até a unificação de 30/10/2026 só existia em `ConvocacaoAtletaBaseRow` (0059_convocacao_
   * atleta_base_numero_camisa.sql) — editável só quando a categoria do jogo é de Base; o
   * Profissional continua lendo o número fixo do cadastro do atleta (`AtletaRow.numero_camisa`). */
  numero_camisa: number | null;
}

export interface ConvocacaoComissaoRow {
  convocacao_id: string;
  comissao_id: string;
}

export interface ConvocacaoStaffRow {
  convocacao_id: string;
  staff_id: string;
}

export type SumulaEventoTipo = "gol" | "cartao_amarelo" | "cartao_vermelho" | "substituicao";
/** "terceiro" só existe na Base, pros jogos vinculados a uma competição com `numero_tempos = 3`
 * (ver docs/superpowers/specs/2026-10-21-competicoes-formato-partida-design.md) — no Profissional
 * (sempre 2 tempos) nunca aparece. */
export type SumulaTempo = "primeiro" | "segundo" | "terceiro";

/** Súmula do jogo — uma linha por jogo (`jogo_id` único). O placar em si continua vivendo em
 * `jogos.gols_pro`/`gols_contra` (única fonte de verdade, editável tanto na aba "Dados do jogo"
 * quanto aqui); esta tabela guarda só a duração de cada tempo. Ver
 * docs/superpowers/specs/2026-08-04-sumula-design.md. */
export interface SumulaRow {
  id: string;
  jogo_id: string;
  duracao_primeiro_tempo: number;
  duracao_segundo_tempo: number;
  /** Sempre null no Profissional — a coluna existe só porque
   * `lib/futebol/estatisticas-atleta-query.ts` usa o mesmo select parametrizado pros dois
   * departamentos (ver `SumulaBaseRow.duracao_terceiro_tempo`). */
  duracao_terceiro_tempo: number | null;
  /** Acréscimo (tempo extra/compensação) de cada tempo, à parte da duração regulamentar — somado
   * só pro cálculo do relógio do jogo (fim de jogo, minutagem de cada atleta), nunca sobrescreve
   * `duracao_primeiro_tempo` etc. Default 0 (nenhum acréscimo lançado). Ver
   * 0147_sumula_acrescimo.sql e `lib/futebol/estatisticas-atleta.ts`. */
  acrescimo_primeiro_tempo: number;
  acrescimo_segundo_tempo: number;
  /** Sempre 0 no Profissional (só existe pela mesma razão de `duracao_terceiro_tempo` acima). */
  acrescimo_terceiro_tempo: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Evento da súmula (gol, cartão amarelo/vermelho, substituição) — cada um salvo individualmente
 * (sem lote), pra não perder lançamentos feitos ao vivo durante o jogo. `atleta_id` é quem fez o
 * gol / recebeu o cartão / saiu (substituição); `atleta_entrou_id` só é usado quando
 * tipo = "substituicao"; `atleta_assistencia_id` só é usado quando tipo = "gol", e é opcional
 * mesmo nesse caso. `ordem` desempata visualmente eventos com o mesmo tempo/minuto. */
export interface SumulaEventoRow {
  id: string;
  sumula_id: string;
  tipo: SumulaEventoTipo;
  tempo: SumulaTempo;
  minuto: number;
  atleta_id: string | null;
  atleta_entrou_id: string | null;
  atleta_assistencia_id: string | null;
  /** Nome do jogador do time ADVERSÁRIO que fez esse gol, quando o evento não é de um atleta
   * nosso (`atleta_id` fica null nesse caso) — usado pela importação de súmula em PDF, pra
   * registrar o placar completo mesmo sem ter esse jogador cadastrado. `SumulaEventoBaseRow` tem
   * a mesma coluna (ver 0128_sumula_base_importacao_fpf.sql). */
  nome_adversario: string | null;
  /** true só quando `nome_adversario` é um gol CONTRA marcado por um jogador do adversário — esse
   * gol favorece o Juventus, ao contrário de um gol normal do adversário (que é contra nós). Sem
   * essa distinção os dois casos ficavam idênticos na tela (bug real de produção — ver
   * 0058_sumula_evento_gol_contra_favor.sql). Sempre false quando `nome_adversario` é null. */
  gol_contra_favor_juventus: boolean;
  ordem: number;
  created_by: string | null;
  created_at: string;
}

export interface RoomingListRow {
  id: string;
  jogo_id: string;
  hotel_nome: string | null;
  hotel_endereco: string | null;
  checkin: string | null;
  checkout: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export type PessoaTipoRooming = "atleta" | "comissao" | "staff";

export interface RoomingListQuartoRow {
  id: string;
  rooming_list_id: string;
  tipo: TipoQuarto;
  ordem: number;
  numero_apartamento: string | null;
}

export interface RoomingListOcupanteRow {
  quarto_id: string;
  pessoa_tipo: PessoaTipoRooming;
  pessoa_id: string;
}

export interface OnibusListaRow {
  id: string;
  jogo_id: string;
  onibus_numero: number;
  horario_saida: string | null;
  created_by: string | null;
  created_at: string;
}

export type PessoaTipoOnibus = "atleta" | "comissao" | "staff";

export interface OnibusPassageiroRow {
  onibus_lista_id: string;
  pessoa_tipo: PessoaTipoOnibus;
  pessoa_id: string;
}

export interface CredenciamentoCatalogoRow {
  id: string;
  zona: string;
  zona_cor: string | null;
  funcao: string;
  vagas_totais: number;
}

export type PessoaTipoCredenciamento = "comissao" | "staff";

export interface CredenciamentoJogoRow {
  id: string;
  jogo_id: string;
  credenciamento_catalogo_id: string;
  pessoa_tipo: PessoaTipoCredenciamento;
  pessoa_id: string;
  vaga_extra: boolean;
  created_at: string;
}

export type PessoaTipoRecibo = "comissao" | "staff";

export interface ReciboJogoRow {
  id: string;
  jogo_id: string;
  pessoa_tipo: PessoaTipoRecibo;
  pessoa_id: string;
  funcao_jogo: string | null;
  valor: number | null;
  chave_pix: string | null;
  // Mesmo conjunto de tipos de Staff Operacional (ver StaffChavePixTipo) desde a migração 0039, que
  // unificou os tipos de chave PIX de Recibos de Jogos com os de Staff Operacional/Solicitações
  // (antes aceitava só 'celular'/'email'/'cpf'/'aleatoria', sem CNPJ e com "celular" em vez de
  // "telefone").
  chave_pix_tipo: StaffChavePixTipo | null;
  pago: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Categoria de evento manual do widget "Calendário" (`app/profissional/page.tsx`) — cor fixa por
 * categoria, ver `lib/futebol/calendario.ts`. Jogos não passam por aqui (vêm de `jogos` direto). */
export type EventoCalendarioCategoria = "treino" | "viagem" | "reuniao" | "prazo" | "outro";

export interface EventoCalendarioRow {
  id: string;
  categoria: EventoCalendarioCategoria;
  titulo: string;
  data: string;
  horario: string | null;
  observacao: string | null;
  created_by: string | null;
  created_at: string;
}

export type TarefaCategoria = "logistica" | "registro" | "financeiro" | "solicitacoes" | "gerais";
export type TarefaStatus = "pendente" | "em_andamento" | "solicitado" | "concluido";

export interface TarefaRow {
  id: string;
  titulo: string;
  descricao: string | null;
  categoria: TarefaCategoria;
  status: TarefaStatus;
  prazo: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface CategoriaGastoRow {
  id: string;
  nome: string;
  created_at: string;
}

export interface GastoJogoRow {
  id: string;
  jogo_id: string;
  categoria_id: string;
  descricao: string | null;
  valor_previsto: number;
  valor_efetuado: number | null;
  data: string | null;
  /** "pre_jogo" | "pos_jogo" | null — null = gasto lançado antes desta feature ("sem fase
   * definida"). Ver docs/superpowers/specs/2026-10-14-gastos-jogo-fase-design.md. */
  fase: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Linha de gastos_jogo já com a categoria embutida via join (`categoria:categorias_gasto(nome)`). */
export interface GastoJogoComCategoriaRow extends GastoJogoRow {
  categoria: { nome: string } | null;
}

/** Despesa avulsa: gasto que não pertence a nenhum jogo (folha de pagamento, manutenção do CT,
 * etc.), mesmo formato de GastoJogoRow sem jogo_id — ver
 * docs/superpowers/specs/2026-08-08-despesas-avulsas-design.md. */
export interface DespesaAvulsaRow {
  id: string;
  categoria_id: string;
  descricao: string | null;
  data: string | null;
  valor_previsto: number;
  valor_efetuado: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Linha de despesas_avulsas já com a categoria embutida via join. */
export interface DespesaAvulsaComCategoriaRow extends DespesaAvulsaRow {
  categoria: { nome: string } | null;
}

/** Vínculo N:N entre uma despesa avulsa e um jogo — só referência/etiqueta, não usado em nenhum
 * cálculo do resumo financeiro do jogo. */
export interface DespesaAvulsaJogoRow {
  despesa_id: string;
  jogo_id: string;
}

/** Espelha `DespesaAvulsaRow`, mas para o Gasto Geral da Base — tabela `despesas_avulsas_base`,
 * sem vínculo com jogos (fora de escopo, ver docs/superpowers/specs/2026-08-19-financeiro-base-
 * design.md), mais `categoria` (idade): `null` = despesa geral da Base, não amarrada a uma
 * categoria específica. */
export interface DespesaAvulsaBaseRow {
  id: string;
  categoria_id: string;
  categoria: CategoriaBase | null;
  descricao: string | null;
  data: string | null;
  valor_previsto: number;
  valor_efetuado: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Linha de despesas_avulsas_base já com o tipo de despesa embutido via join. */
export interface DespesaAvulsaBaseComCategoriaRow extends DespesaAvulsaBaseRow {
  categoria_gasto: { nome: string } | null;
}

/**
 * Configurações do módulo Financeiro — tabela singleton (sempre uma linha só) com as duas
 * assinaturas usadas nos PDFs (Orçamento Previsto e Relatório Geral).
 */
export interface ConfiguracaoFinanceiroRow {
  id: string;
  /** Unificação de Jogos/Convocação, 30/10/2026 — ver 0157_unificacao_jogos.sql. Mesma ideia de
   * `AtletaRow.categoria`, no nível de departamento em vez de categoria de idade (esta tabela é
   * singleton por departamento, não tem uma linha por jogo). */
  departamento: "futebol_profissional" | "futebol_base";
  assinatura1_nome: string;
  assinatura1_cargo: string;
  assinatura2_nome: string;
  assinatura2_cargo: string;
  /** Usuário do sistema vinculado a cada assinante (ver docs/superpowers/specs/
   * 2026-08-28-assinatura-digital-notificacoes-design.md) — `null` = nenhum vinculado ainda, e
   * nesse caso qualquer "master" pode assinar aquele papel digitalmente. */
  assinatura1_usuario_id: string | null;
  assinatura2_usuario_id: string | null;
  updated_at: string;
}

/**
 * Liga/desliga o link público de autocadastro de Staff Operacional (/cadastro-staff) — tabela
 * singleton (sempre uma linha só).
 */
export interface ConfiguracaoCadastroStaffRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/** Mesma coisa, mas pro autocadastro de Staff Operacional do Futebol de Base (/cadastro-staff-base)
 * — tabela totalmente independente da do Profissional. */
export interface ConfiguracaoCadastroStaffBaseRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/** Liga/desliga o link público de autocadastro da Comissão Técnica/Diretoria — Profissional
 * (/cadastro-comissao-tecnica) — tabela singleton, totalmente independente das de Staff Operacional
 * (ver docs/superpowers/specs/2026-08-25-comissao-tecnica-cadastro-publico-design.md). */
export interface ConfiguracaoCadastroComissaoTecnicaRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/** Mesma coisa, mas pro autocadastro da Comissão Técnica/Diretoria do Futebol de Base
 * (/cadastro-comissao-tecnica-base). */
export interface ConfiguracaoCadastroComissaoTecnicaBaseRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/**
 * Item do checklist de preparação de um jogo. Os itens são criados automaticamente a partir de um
 * modelo fixo (ver lib/checklist-templates.ts) na primeira vez que a aba "Checklist" do jogo é
 * aberta — a lista de itens muda conforme o jogo é em casa ou fora.
 */
export interface ChecklistJogoItemRow {
  id: string;
  jogo_id: string;
  item: string;
  concluido: boolean;
  prazo: string | null;
  ordem: number;
  created_at: string;
  updated_at: string;
}

/** Linha de checklist_jogo_itens já com os dados do jogo embutidos via join (`jogo:jogos(...)`). */
export interface ChecklistJogoItemComJogoRow extends ChecklistJogoItemRow {
  jogo: { id: string; adversario_nome: string; data_jogo: string; mandante: boolean } | null;
}

// =========================================================
// FUTEBOL DE BASE — Jogos + Financeiro (Fase 3, ver
// docs/superpowers/specs/2026-07-20-futebol-de-base-design.md). Espelham exatamente as
// interfaces acima, só acrescentando `categoria` em jogos_base (igual a atletas_base/
// comissao_tecnica_base) — o restante do universo de Jogos (checklist, convocação, logística,
// recibo, programação) não tem categoria própria, ela vem sempre do jogo. Credenciamento por
// zona e Carga de Ingressos ficam fora de escopo pro Futebol de Base.
// =========================================================

export interface JogoBaseRow {
  id: string;
  categoria: CategoriaBase;
  competicao: string;
  rodada_fase: string | null;
  adversario_nome: string;
  adversario_logo_path: string | null;
  data_jogo: string;
  horario: string | null;
  local_estadio: string | null;
  endereco: string | null;
  mandante: boolean;
  gols_pro: number | null;
  gols_contra: number | null;
  concentracao_data: string | null;
  concentracao_regras: string;
  dia_jogo_liberacao: string | null;
  /** Ver comentário de `JogoRow.fpf_link_sumula` — mesmo campo, pra importação de súmula por link
   * nos jogos da Base (ver 0128_sumula_base_importacao_fpf.sql e
   * docs/superpowers/specs/2026-10-03-importacao-sumula-base-design.md). */
  fpf_link_sumula?: string | null;
  /** Placar da disputa de pênaltis (jogos de mata-mata que empataram) — só Base por enquanto, ver
   * 0146_sumula_pdf_terceiro_tempo_penaltis.sql. Null = não houve disputa ou ainda não informado. */
  penaltis_pro: number | null;
  penaltis_contra: number | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface JogoProgramacaoItemBaseRow {
  id: string;
  jogo_id: string;
  tipo: ProgramacaoTipo;
  ordem: number;
  horario: string;
  atividade: string;
  local: string;
  eh_confronto: boolean;
  created_at: string;
}

export interface ChecklistJogoItemBaseRow {
  id: string;
  jogo_id: string;
  item: string;
  concluido: boolean;
  prazo: string | null;
  ordem: number;
  created_at: string;
  updated_at: string;
}

export interface ConvocacaoBaseRow {
  id: string;
  jogo_id: string;
  capitao_atleta_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ConvocacaoAtletaBaseRow {
  convocacao_id: string;
  atleta_id: string;
  status: ConvocacaoAtletaStatus;
  /** Número da camisa NESSA convocação (jogo) — diferente de `atletas_base.numero_camisa`, que é
   * fixo por atleta. Na Base a numeração muda de jogo pra jogo, então é editada aqui mesmo, na
   * tela de Convocação, vindo sempre em branco (`null`) até alguém preencher. Ver
   * 0059_convocacao_atleta_base_numero_camisa.sql. Só Futebol de Base — `ConvocacaoAtletaRow`
   * (Profissional) não tem essa coluna, porque lá o número já é fixo no cadastro do atleta. */
  numero_camisa: number | null;
}

export interface ConvocacaoComissaoBaseRow {
  convocacao_id: string;
  comissao_id: string;
}

export interface ConvocacaoStaffBaseRow {
  convocacao_id: string;
  staff_id: string;
}

/** Espelha `SumulaRow`, mas para o Futebol de Base — tabela `sumulas_base`, `jogo_id` referencia
 * `jogos_base`. */
export interface SumulaBaseRow {
  id: string;
  jogo_id: string;
  duracao_primeiro_tempo: number;
  duracao_segundo_tempo: number;
  /** Duração do 3º tempo — só preenchida quando o jogo está vinculado (via
   * `competicao_jogos_base`) a uma competição com `numero_tempos = 3` (ver
   * docs/superpowers/specs/2026-10-21-competicoes-formato-partida-design.md). Null em todos os
   * outros jogos da Base, exatamente como nos de 2 tempos de sempre. */
  duracao_terceiro_tempo: number | null;
  /** Ver comentário de `SumulaRow.acrescimo_primeiro_tempo` — mesmas 3 colunas, ver
   * 0147_sumula_acrescimo.sql. */
  acrescimo_primeiro_tempo: number;
  acrescimo_segundo_tempo: number;
  acrescimo_terceiro_tempo: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Espelha `SumulaEventoRow`, mas para o Futebol de Base — tabela `sumula_eventos_base`, atletas
 * referenciam `atletas_base`. */
export interface SumulaEventoBaseRow {
  id: string;
  sumula_id: string;
  tipo: SumulaEventoTipo;
  tempo: SumulaTempo;
  minuto: number;
  atleta_id: string | null;
  atleta_entrou_id: string | null;
  atleta_assistencia_id: string | null;
  /** Ver comentário de `SumulaEventoRow.nome_adversario`/`gol_contra_favor_juventus` — mesmas duas
   * colunas, pra importação de súmula por link nos jogos da Base (ver
   * 0128_sumula_base_importacao_fpf.sql). */
  nome_adversario: string | null;
  gol_contra_favor_juventus: boolean;
  ordem: number;
  created_by: string | null;
  created_at: string;
}

export interface RoomingListBaseRow {
  id: string;
  jogo_id: string;
  hotel_nome: string | null;
  hotel_endereco: string | null;
  checkin: string | null;
  checkout: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface RoomingListQuartoBaseRow {
  id: string;
  rooming_list_id: string;
  tipo: TipoQuarto;
  ordem: number;
  numero_apartamento: string | null;
}

export interface RoomingListOcupanteBaseRow {
  quarto_id: string;
  pessoa_tipo: PessoaTipoRooming;
  pessoa_id: string;
}

export interface OnibusListaBaseRow {
  id: string;
  jogo_id: string;
  onibus_numero: number;
  horario_saida: string | null;
  created_by: string | null;
  created_at: string;
}

export interface OnibusPassageiroBaseRow {
  onibus_lista_id: string;
  pessoa_tipo: PessoaTipoOnibus;
  pessoa_id: string;
}

export interface ReciboJogoBaseRow {
  id: string;
  jogo_id: string;
  pessoa_tipo: PessoaTipoRecibo;
  pessoa_id: string;
  funcao_jogo: string | null;
  valor: number | null;
  chave_pix: string | null;
  chave_pix_tipo: StaffChavePixTipo | null;
  pago: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface GastoJogoBaseRow {
  id: string;
  jogo_id: string;
  categoria_id: string;
  descricao: string | null;
  valor_previsto: number;
  valor_efetuado: number | null;
  data: string | null;
  /** "pre_jogo" | "pos_jogo" | null — null = gasto lançado antes desta feature ("sem fase
   * definida"). Ver docs/superpowers/specs/2026-10-14-gastos-jogo-fase-design.md. */
  fase: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Linha de gastos_jogo_base já com a categoria embutida via join (`categoria:categorias_gasto(nome)`). */
export interface GastoJogoBaseComCategoriaRow extends GastoJogoBaseRow {
  categoria: { nome: string } | null;
}

/** Configurações do Financeiro (Base) — tabela singleton independente da do Profissional.
 * `assinatura1_usuario_id` deixou de existir (ver docs/superpowers/specs/2026-10-27-assinatura-
 * financeiro-base-por-supervisor-design.md) — quem pode assinar a Assinatura 1 de cada jogo agora
 * vem da função/categorias cadastradas na Comissão Técnica da Base, não de um vínculo fixo aqui. */
export interface ConfiguracaoFinanceiroBaseRow {
  id: string;
  assinatura1_nome: string;
  assinatura1_cargo: string;
  assinatura2_nome: string;
  assinatura2_cargo: string;
  assinatura2_usuario_id: string | null;
  updated_at: string;
}

export type SolicitacaoTipo =
  | "compra"
  | "pagamento"
  | "exame_medico"
  | "reembolso"
  | "passagem_aerea"
  | "transporte"
  | "hospedagem";
export type SolicitacaoStatus = "pendente" | "aprovada" | "recusada" | "concluida";
export type SolicitacaoTipoConta = "corrente" | "poupanca";

/**
 * Solicitação formal (Compra, Pagamento, Exame Médico, Reembolso ou Passagem Aérea), gerada no
 * modelo de PDF do clube. `valor` só é usado em Pagamento/Reembolso, e é calculado automaticamente
 * como a soma dos itens (ver SolicitacaoItemRow); `chave_pix`/`chave_pix_tipo` e os dados bancários
 * (`banco`/`agencia`/`conta`/`tipo_conta`/`titular_conta`) são usados em Pagamento e Reembolso —
 * ambos opcionais, a pessoa preenche o que for mais conveniente pro caso.
 * `passageiro`/`origem`/`destino`/`data_voo`/`horario_voo` não são mais preenchidos (ficaram em
 * solicitacao_itens, já que uma Passagem Aérea pode ter vários passageiros) — as colunas continuam
 * aqui só por compatibilidade com registros antigos.
 */
export interface SolicitacaoRow {
  id: string;
  numero: number;
  tipo: SolicitacaoTipo;
  data_solicitacao: string;
  solicitante: string;
  setor: string;
  descricao_necessidade: string | null;
  prazo_sugerido: string | null;
  valor: number | null;
  chave_pix: string | null;
  chave_pix_tipo: StaffChavePixTipo | null;
  banco: string | null;
  agencia: string | null;
  conta: string | null;
  tipo_conta: SolicitacaoTipoConta | null;
  titular_conta: string | null;
  passageiro: string | null;
  origem: string | null;
  destino: string | null;
  data_voo: string | null;
  horario_voo: string | null;
  status: SolicitacaoStatus;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/**
 * Item de uma solicitação — o significado dos campos depende do tipo da solicitação "pai":
 * - Compra: quantidade + item + foto_path
 * - Pagamento / Reembolso: descricao + observacao (opcional) + valor
 * - Passagem Aérea: passageiro + origem + destino + data_voo + horario_voo + observacao (opcional)
 * - Transporte: mesmas colunas de Passagem Aérea (passageiro/origem/destino/data_voo/horario_voo),
 *   mais valor — é um tipo de solicitação separado, mas reaproveita as colunas por terem o mesmo
 *   formato de campos.
 * - Hospedagem: passageiro + cidade + hotel + data_entrada + data_saida + tipo_acomodacao + valor
 * Exame Médico não usa itens. Todos os campos além de id/solicitacao_id/ordem/created_at são
 * opcionais, já que cada solicitação só preenche o conjunto relevante ao seu tipo.
 */
export interface SolicitacaoItemRow {
  id: string;
  solicitacao_id: string;
  quantidade: string | null;
  item: string | null;
  foto_path: string | null;
  descricao: string | null;
  observacao: string | null;
  valor: number | null;
  passageiro: string | null;
  origem: string | null;
  destino: string | null;
  data_voo: string | null;
  horario_voo: string | null;
  cidade: string | null;
  hotel: string | null;
  data_entrada: string | null;
  data_saida: string | null;
  tipo_acomodacao: string | null;
  // Exclusivos de Exame Médico — origem/destino/data_voo/horario_voo (acima) são reaproveitados
  // pro trecho de IDA do transporte; estes cobrem o exame em si e o trecho de VOLTA.
  data_exame: string | null;
  local_exame: string | null;
  houve_transporte: boolean;
  origem_volta: string | null;
  destino_volta: string | null;
  data_volta: string | null;
  horario_volta: string | null;
  ordem: number;
  created_at: string;
}

/** "medico" é o valor gravado da ramificação hoje chamada de **Medicamentos** na interface — ver
 * ESTOQUE_CATEGORIAS em lib/validation/schemas.ts. */
export type EstoqueCategoria = "esportivo" | "medico" | "materiais";

/**
 * Item do catálogo de Estoque — Esportivo, Medicamentos e Materiais são listas totalmente independentes,
 * nunca se misturam (nem no catálogo, nem em Entradas/Saídas). `tamanhos` guarda a quantidade de
 * cada tamanho/variação num objeto só (ex: {"P": 12, "M": 20, "Único": 5}) — o item inteiro é uma
 * linha só, não uma linha por tamanho. A quantidade só muda através de Entrada (soma) ou Saída
 * (subtrai); editar o item corrige nome/código/tamanhos diretamente, pra consertar um engano.
 * No Médico, o mesmo campo `tamanhos` guarda as unidades de medida (ex: {"Caixa": 4, "Unidade": 10})
 * em vez de tamanhos de roupa — só muda o rótulo mostrado na tela, o dado é o mesmo. `mg` é usado só
 * pelo Médico (dosagem/concentração, ex: "500mg"), opcional e não usado no Esportivo.
 */
export interface EstoqueItemRow {
  id: string;
  categoria: EstoqueCategoria;
  nome: string;
  codigo: string | null;
  mg: string | null;
  tamanhos: Record<string, number>;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/**
 * Ficha de Saída (retirada de material por um colaborador) — "numero" é sequencial e independente
 * por categoria (cada ramificação com sua própria contagem 0001, 0002...).
 */
export interface EstoqueSaidaRow {
  id: string;
  categoria: EstoqueCategoria;
  numero: number;
  data: string;
  nome_destinatario: string;
  funcao: string | null;
  departamento: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface EstoqueSaidaItemRow {
  id: string;
  saida_id: string;
  item_id: string | null;
  nome: string;
  tamanho: string | null;
  codigo: string | null;
  quantidade: number;
  ordem: number;
  created_at: string;
}

/** Entrada de estoque (reposição/material que chegou) — registro simples, sem assinatura; soma
 * direto nas quantidades do item. "numero" também sequencial e independente por categoria, numa
 * contagem separada da de Saídas. */
export interface EstoqueEntradaRow {
  id: string;
  categoria: EstoqueCategoria;
  numero: number;
  data: string;
  fornecedor: string | null;
  nota_fiscal: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface EstoqueEntradaItemRow {
  id: string;
  entrada_id: string;
  item_id: string | null;
  nome: string;
  tamanho: string | null;
  codigo: string | null;
  quantidade: number;
  ordem: number;
  created_at: string;
}

/**
 * Futebol de Base — Estoque e Solicitações (Fase 4, ver a spec). Nenhum dos dois ganha a dimensão
 * `categoria` (Sub-20 a Sub-11): Solicitações já era uma lista única no Profissional, e o Estoque do
 * Base só tem material esportivo (Estoque Médico está fora de escopo), então nem existe uma coluna
 * `categoria` aqui — ao contrário de `EstoqueItemRow`, que tem três listas.
 */
export interface EstoqueItemBaseRow {
  id: string;
  nome: string;
  codigo: string | null;
  mg: string | null;
  tamanhos: Record<string, number>;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface EstoqueSaidaBaseRow {
  id: string;
  numero: number;
  data: string;
  nome_destinatario: string;
  funcao: string | null;
  departamento: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface EstoqueSaidaItemBaseRow {
  id: string;
  saida_id: string;
  item_id: string | null;
  nome: string;
  tamanho: string | null;
  codigo: string | null;
  quantidade: number;
  ordem: number;
  created_at: string;
}

export interface EstoqueEntradaBaseRow {
  id: string;
  numero: number;
  data: string;
  fornecedor: string | null;
  nota_fiscal: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface EstoqueEntradaItemBaseRow {
  id: string;
  entrada_id: string;
  item_id: string | null;
  nome: string;
  tamanho: string | null;
  codigo: string | null;
  quantidade: number;
  ordem: number;
  created_at: string;
}

/** Configuração do Encarregado do Departamento que assina digitalmente as Solicitações do Futebol
 * Profissional (ver docs/superpowers/specs/2026-08-28-assinatura-digital-notificacoes-design.md,
 * Fase 2) — tabela singleton, mesmo espírito de `ConfiguracaoFinanceiroRow`. Ver
 * `ConfiguracaoSolicitacoesBaseRow` abaixo para o Futebol de Base (tabela independente). */
export interface ConfiguracaoSolicitacoesRow {
  id: string;
  encarregado_nome: string;
  encarregado_cargo: string;
  encarregado_usuario_id: string | null;
  /** Departamento de Compras/Financeiro e Aprovador (ver docs/superpowers/specs/2026-08-28-
   * assinatura-digital-notificacoes-design.md — papéis que o PDF antigo tinha e voltaram a pedido
   * do Mateus, agora com assinatura desenhada de verdade). `compras_*`/`financeiro_*` nunca
   * assinam a mesma solicitação — o tipo decide qual dos dois aparece (ver
   * `papelDepartamentoSolicitacao` em lib/assinaturas/config.ts); `aprovador_*` é o mesmo em
   * qualquer tipo. */
  compras_cargo: string;
  compras_usuario_id: string | null;
  financeiro_cargo: string;
  financeiro_usuario_id: string | null;
  aprovador_cargo: string;
  aprovador_usuario_id: string | null;
  updated_at: string;
}

/** Mesma coisa que `ConfiguracaoSolicitacoesRow`, mas para o Futebol de Base
 * (`configuracoes_solicitacoes_base` — tabela totalmente independente). */
export interface ConfiguracaoSolicitacoesBaseRow {
  id: string;
  encarregado_nome: string;
  encarregado_cargo: string;
  encarregado_usuario_id: string | null;
  compras_cargo: string;
  compras_usuario_id: string | null;
  financeiro_cargo: string;
  financeiro_usuario_id: string | null;
  aprovador_cargo: string;
  aprovador_usuario_id: string | null;
  updated_at: string;
}

/** Config singleton de quem é o "Departamento" no Relatório de Dispensa — só Base, mesmo padrão de
 * ConfiguracaoSolicitacoesRow, mas sem nome/cargo porque o rótulo já é fixo (ver PAPEIS_FIXOS em
 * lib/assinaturas/config.ts). Sem vincular ninguém, qualquer master pode assinar (podeAssinarPapel). */
export interface ConfiguracaoDispensaBaseRow {
  id: string;
  departamento_usuario_id: string | null;
  updated_at: string;
}

export interface SolicitacaoBaseRow {
  id: string;
  numero: number;
  tipo: SolicitacaoTipo;
  data_solicitacao: string;
  solicitante: string;
  setor: string;
  descricao_necessidade: string | null;
  prazo_sugerido: string | null;
  valor: number | null;
  chave_pix: string | null;
  chave_pix_tipo: StaffChavePixTipo | null;
  banco: string | null;
  agencia: string | null;
  conta: string | null;
  tipo_conta: SolicitacaoTipoConta | null;
  titular_conta: string | null;
  passageiro: string | null;
  origem: string | null;
  destino: string | null;
  data_voo: string | null;
  horario_voo: string | null;
  status: SolicitacaoStatus;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface SolicitacaoItemBaseRow {
  id: string;
  solicitacao_id: string;
  quantidade: string | null;
  item: string | null;
  foto_path: string | null;
  descricao: string | null;
  observacao: string | null;
  valor: number | null;
  passageiro: string | null;
  origem: string | null;
  destino: string | null;
  data_voo: string | null;
  horario_voo: string | null;
  cidade: string | null;
  hotel: string | null;
  data_entrada: string | null;
  data_saida: string | null;
  tipo_acomodacao: string | null;
  // Exclusivos de Exame Médico — origem/destino/data_voo/horario_voo (acima) são reaproveitados
  // pro trecho de IDA do transporte; estes cobrem o exame em si e o trecho de VOLTA.
  data_exame: string | null;
  local_exame: string | null;
  houve_transporte: boolean;
  origem_volta: string | null;
  destino_volta: string | null;
  data_volta: string | null;
  horario_volta: string | null;
  ordem: number;
  created_at: string;
}

export type PerfilRole = "master" | "regular" | "treinador" | "financeiro";

/** Papel de cada usuário logado — "master" pode excluir Entrada/Saída do Estoque, acessar a tela
 * de Usuários (/usuarios) e sempre tem acesso a todos os módulos, independente de
 * `modulos_permitidos`; "regular" usa só os módulos liberados pra ele (ver `lib/auth/modulos.ts`);
 * "treinador" não usa nada disso — cai direto em `/treinador` (ver `lib/supabase/middleware.ts`) e
 * só enxerga os candidatos da Captação nas categorias de `categorias_treinador`, pra preencher o
 * Parecer Final (ver docs/superpowers/specs/2026-08-19-parecer-final-treinador-design.md);
 * "financeiro" também não usa nada disso — cai direto em `/area-financeira`, uma área isolada só
 * com os jogos (Profissional e Base) e o Financeiro de cada um em modo só-leitura (ver
 * docs/superpowers/specs/2026-10-22-area-financeira-design.md). */
export interface PerfilRow {
  id: string;
  email: string;
  role: PerfilRole;
  modulos_permitidos: string[];
  modulos_base_permitidos: string[];
  departamentos_permitidos: string[];
  tarefas_categorias_visiveis: string[];
  estoque_categorias_permitidas: string[];
  /** Só usada quando `role = 'treinador'`. Cada item é uma `CategoriaBase`. Pode ter mais de uma
   * (ex.: um treinador que cobre Sub-11 e Sub-12 ao mesmo tempo). */
  categorias_treinador: string[];
  /** Nome e cargo de exibição, preenchidos pela própria pessoa em `/minha-conta` — usados na
   * assinatura digital de documentos (ver docs/superpowers/specs/2026-08-28-assinatura-digital-
   * notificacoes-design.md). `null` até a pessoa preencher pela primeira vez. */
  nome: string | null;
  cargo: string | null;
  /** Caminho (Storage, bucket `assinaturas`) da assinatura desenhada/anexada ATUAL da conta — a
   * mais recente cadastrada em `/minha-conta` (ver docs/superpowers/specs/2026-09-13-assinatura-
   * desenhada-design.md). `null` até a pessoa cadastrar pela primeira vez; trocar depois não afeta
   * documentos já assinados (snapshot em `assinaturas_documento.assinatura_path`). */
  assinatura_path: string | null;
  /** Vínculo "vivo" com um registro da Comissão Técnica (ver docs/superpowers/specs/2026-09-13-
   * acesso-por-categoria-comissao-tecnica-design.md) — quando preenchido, nome/função pra
   * assinatura digital passam a vir do registro vinculado em vez de `nome`/`cargo` acima (ver
   * `resolverNomeCargoParaAssinatura`), e `nome`/`cargo` desta linha viram somente-leitura em
   * `/minha-conta`. `comissao_tecnica_id` é do Futebol Profissional; `comissao_tecnica_base_id` é
   * do Futebol de Base e também passa a decidir `categorias_base_permitidas` (ver
   * `getCategoriasBasePermitidas`) — se os dois estiverem preenchidos (não deveria acontecer em uso
   * normal), o vínculo da Base tem prioridade. `null` até alguém vincular pela tela de Usuários. */
  comissao_tecnica_id: string | null;
  comissao_tecnica_base_id: string | null;
  /** Categorias do Futebol de Base que esta pessoa pode ver/acessar (Atletas, Jogos e tudo dentro
   * de um jogo) — só usada quando `comissao_tecnica_base_id` está vazio (sem vínculo, o vínculo
   * sempre tem prioridade e usa as categorias do próprio registro da Comissão Técnica). Segue a
   * mesma convenção de todo o resto de `perfis`: "not null default <lista completa>", nunca "vazio
   * = tudo liberado". */
  categorias_base_permitidas: string[];
  /** Sub-área Fisioterapia do módulo Departamento Médico (Futebol Profissional) — ver docs/
   * superpowers/specs/2026-09-30-fisioterapia-design.md. "Master" sempre pode editar independente
   * desta coluna (regra geral do sistema); "regular" só grava lesões/queixas/atendimentos quando
   * isto é `true` (o fisioterapeuta) — os demais com o módulo liberado só visualizam. `false` por
   * padrão: liberar o módulo pra alguém não dá poder de edição sozinho. */
  fisioterapia_pode_editar: boolean;
  /** Mesma ideia de `fisioterapia_pode_editar`, mas pro módulo Departamento Médico do Futebol de
   * Base — permissão própria, independente (normalmente é outra pessoa cuidando da Base). Ver
   * docs/superpowers/specs/2026-10-06-fisioterapia-base-design.md. */
  fisioterapia_pode_editar_base: boolean;
  /** Campos sensíveis (catálogo em `lib/auth/campos-sensiveis.ts`, hoje só "salario") escondidos
   * desta pessoa mesmo com o módulo correspondente liberado — ver docs/superpowers/specs/
   * 2026-10-02-campos-sensiveis-e-atletas-por-categoria-design.md. Lista de BLOQUEIO (ao contrário
   * da maioria das colunas acima, que são do que É permitido): vazio = nada escondido. "Master"
   * nunca é afetado, qualquer que seja o valor aqui. */
  campos_sensiveis_bloqueados: string[];
  /** Aparece no Painel de Demandas do master (`/demandas`) e no widget "Minhas Demandas" da tela
   * inicial desta pessoa — ver docs/superpowers/specs/2026-10-05-assistencia-social-e-demandas-
   * design.md, Parte 2. `false` por padrão: a tela `/minhas-demandas` continua funcionando pra
   * qualquer um independente disto, só não aparece sozinha na sidebar/tela inicial. */
  demandas_acompanhado: boolean;
  /** Pode usar a ação "Transitar atleta" (ver docs/superpowers/specs/2026-11-04-atletas-
   * desativacao-transicao-pagamento-design.md) pra trocar a categoria de qualquer atleta (Base ou
   * Profissional) — dá acesso "emprestado" a categorias fora de `categorias_base_permitidas`/
   * `departamentos_permitidos`, só pra essa ação. "Master" sempre pode, independente desta coluna
   * (mesma regra geral de `fisioterapia_pode_editar`). `false` por padrão. */
  pode_transitar_categoria_atleta: boolean;
  created_at: string;
}

// ===== Competições (ver docs/superpowers/specs/2026-08-10-competicoes-design.md) =====

export interface TemporadaRow {
  id: string;
  nome: string;
  created_by: string | null;
  created_at: string;
}

export type CompeticaoStatus = "planejada" | "em_andamento" | "encerrada";

/** Situação do Juventus NESSA competição — independente do `status` acima, que só muda quando o
 * campeonato inteiro termina (com ou sem o Juventus ainda disputando). Campo manual (ver
 * docs/superpowers/specs/2026-10-21-competicoes-formato-partida-design.md): não há cálculo
 * automático a partir dos jogos/classificação por enquanto. */
export type CompeticaoSituacaoClube = "participando" | "eliminado" | "campeao" | "vice";

/** A competição é identificada só pelo nome (sem "tipo", sem nome oficial à parte). As colunas
 * `regra_*` são o motor de regras disciplinares dela — cada campeonato pode ter regra própria. */
export interface CompeticaoRow {
  id: string;
  temporada_id: string;
  nome: string;
  federacao: string | null;
  categoria: string;
  data_inicio: string | null;
  data_termino: string | null;
  status: CompeticaoStatus;
  regulamento_path: string | null;
  observacoes: string | null;
  regra_amarelos_suspensao: number;
  regra_jogos_suspensao_amarelos: number;
  regra_jogos_suspensao_vermelho: number;
  /** Texto livre do regulamento que embasa as regras disciplinares (ex.: Art. 60 da Copa
   * Paulista) — só registro/consulta, o motor usa as colunas `regra_*` acima. */
  regra_observacoes: string | null;
  /** Critérios de desempate da competição, na ordem em que se aplicam (Art. 17 na Copa Paulista,
   * mas configurável — cada campeonato tem os seus). Ver lib/futebol/competicao-desempate.ts. */
  criterios_desempate: string[];
  situacao_clube: CompeticaoSituacaoClube;
  /** Texto livre (ex.: "Terceira Fase") — fases nem sempre estão cadastradas em
   * `competicao_fases`, então não dá pra referenciar uma fase de verdade aqui. */
  situacao_clube_fase: string | null;
  situacao_clube_data: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface CompeticaoComTemporadaRow extends CompeticaoRow {
  temporada: Pick<TemporadaRow, "id" | "nome"> | null;
}

export type CompeticaoFaseStatus = "aguardando" | "em_andamento" | "encerrada";

export interface CompeticaoFaseRow {
  id: string;
  competicao_id: string;
  nome: string;
  ordem: number;
  status: CompeticaoFaseStatus;
  /** Regulamentos como o da Copa Paulista zeram os amarelos ao fim de certas fases ("desde que
   * não seja o terceiro da série"): com true, o acúmulo de amarelos não carrega pras fases
   * seguintes — suspensão já gerada dentro da fase continua valendo (ver
   * lib/futebol/competicao-disciplina.ts). */
  zerar_cartoes_ao_encerrar: boolean;
  /** Critérios de desempate próprios desta fase — null herda os da competição. É assim que o §1º
   * do Art. 17 da Copa Paulista é representado: no play in e no mata-mata valem só os critérios
   * "até a alínea b" (vitórias e saldo), na fase em questão. */
  criterios_desempate: string[] | null;
  created_at: string;
}

export interface CompeticaoGrupoRow {
  id: string;
  fase_id: string;
  nome: string;
  ordem: number;
  created_at: string;
}

/** Equipe de um grupo: ou `nome` fixo, ou vaga projetada de fase anterior
 * (`origem_grupo_id` + `origem_posicao`, ex.: "1º do Grupo 3") resolvida pela classificação. */
export interface CompeticaoGrupoEquipeRow {
  id: string;
  grupo_id: string;
  nome: string | null;
  origem_grupo_id: string | null;
  origem_posicao: number | null;
  ordem: number;
  created_at: string;
}

/** Vínculo do jogo EXISTENTE (`public.jogos`) com competição/fase/grupo — o módulo de Competições
 * nunca cria jogo, só organiza os que já existem. */
export interface CompeticaoJogoRow {
  id: string;
  competicao_id: string;
  jogo_id: string;
  fase_id: string | null;
  grupo_id: string | null;
  /** Cartões do ADVERSÁRIO neste jogo do Juventus — a súmula do sistema só registra cartões dos
   * nossos atletas (que entram sozinhos na contagem da classificação), então o lado do adversário
   * é complementado à mão na aba Súmulas dos Grupos. */
  cartoes_amarelos_adversario: number;
  cartoes_vermelhos_adversario: number;
  /** Link do PDF da súmula oficial usado pra importar os cartões do adversário. */
  sumula_link: string | null;
  created_by: string | null;
  created_at: string;
}

/** Placar entre os OUTROS clubes do grupo (lançamento leve, só pra classificação) — jogos do
 * Juventus nunca entram aqui. */
export interface CompeticaoGrupoResultadoRow {
  id: string;
  grupo_id: string;
  equipe_casa: string;
  equipe_fora: string;
  gols_casa: number;
  gols_fora: number;
  data_jogo: string | null;
  /** Rodada do jogo (texto livre, ex.: "1ª rodada") — só organização da lista. */
  rodada: string | null;
  /** PDF da súmula do jogo anexado (bucket competicao-documentos), quando o Mateus quiser guardar
   * o comprovante do placar lançado. */
  sumula_path: string | null;
  /** Cartões de cada lado, lançados junto do placar — alimentam as colunas CA/CV da classificação
   * (mesmo formato da tabela oficial da FPF). */
  cartoes_amarelos_casa: number;
  cartoes_amarelos_fora: number;
  cartoes_vermelhos_casa: number;
  cartoes_vermelhos_fora: number;
  /** Link do PDF da súmula oficial de onde placar e cartões foram importados (quando veio de
   * link em vez de digitação). */
  sumula_link: string | null;
  created_by: string | null;
  created_at: string;
}

export type CompeticaoListaInscricao = "A" | "B";

export interface CompeticaoInscricaoRow {
  id: string;
  competicao_id: string;
  atleta_id: string;
  lista: CompeticaoListaInscricao | null;
  data_inscricao: string;
  created_by: string | null;
  created_at: string;
}

export type CompeticaoSuspensaoOrigem = "cartao" | "decisao_disciplinar" | "outro";

/** Só suspensão MANUAL (decisão disciplinar externa). As automáticas por cartão são derivadas
 * das súmulas pelo motor de regras (`lib/futebol/competicao-disciplina.ts`) — sem tabela. */
export interface CompeticaoSuspensaoManualRow {
  id: string;
  competicao_id: string;
  atleta_id: string;
  origem: CompeticaoSuspensaoOrigem;
  motivo: string;
  jogos_suspensao: number;
  data_decisao: string;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoPrazoRow {
  id: string;
  competicao_id: string;
  titulo: string;
  data_inicio: string | null;
  data_fim: string;
  concluido: boolean;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoDocumentoRow {
  id: string;
  competicao_id: string;
  nome: string;
  arquivo_path: string;
  created_by: string | null;
  created_at: string;
}

// ===== Competições — Futebol de Base (ver docs/superpowers/specs/
// 2026-10-03-competicoes-base-design.md) — espelham exatamente as interfaces acima, tabelas
// `_base`, só com `CompeticaoBaseRow.categoria` virando `CategoriaBase` (uma competição da Base é
// sempre de uma única categoria, diferente do `categoria: string` livre do Profissional). =====

export interface TemporadaBaseRow {
  id: string;
  nome: string;
  created_by: string | null;
  created_at: string;
}

/** Regra de escalação/substituição de um tempo da partida (só Base — ver
 * `CompeticaoBaseRow.regra_tempo_1`/`regra_tempo_2`/`regra_tempo_3`). O Campeonato Paulista de
 * Base (Art. 19-20 do REC) usa `somente_titulares` no 1º tempo, `somente_reservas` no 2º e
 * `livre_ilimitada` no 3º — "livre" é o padrão de qualquer competição sem essa particularidade. */
export type RegraTempoCompeticao = "livre" | "somente_titulares" | "somente_reservas" | "livre_ilimitada";

export interface CompeticaoBaseRow {
  id: string;
  temporada_id: string;
  nome: string;
  federacao: string | null;
  categoria: CategoriaBase;
  data_inicio: string | null;
  data_termino: string | null;
  status: CompeticaoStatus;
  regulamento_path: string | null;
  observacoes: string | null;
  regra_amarelos_suspensao: number;
  regra_jogos_suspensao_amarelos: number;
  regra_jogos_suspensao_vermelho: number;
  regra_observacoes: string | null;
  criterios_desempate: string[];
  /** Formato de partida — ver docs/superpowers/specs/2026-10-21-competicoes-formato-partida-
   * design.md. Só existe na Base: o Profissional sempre joga 2 tempos de 45min, sem
   * particularidades, então essas colunas nem existem em `competicoes` (Profissional). */
  numero_tempos: 2 | 3;
  duracao_tempo_1_minutos: number | null;
  duracao_tempo_2_minutos: number | null;
  /** Só preenchida quando `numero_tempos = 3`. */
  duracao_tempo_3_minutos: number | null;
  duracao_intervalo_minutos: number | null;
  /** Quantidade mínima obrigatória de atletas na súmula (ex.: 18 no Sub-11/12, 22 no Sub-13/14) —
   * usada só pra gerar aviso na Súmula, nunca bloqueia o salvamento. */
  elenco_minimo_em_campo: number | null;
  /** Minutos mínimos que todo atleta inscrito na súmula deve jogar — mesma regra de aviso. */
  minutos_minimos_por_atleta: number | null;
  regra_tempo_1: RegraTempoCompeticao;
  regra_tempo_2: RegraTempoCompeticao;
  /** Só usado quando `numero_tempos = 3`. */
  regra_tempo_3: RegraTempoCompeticao | null;
  situacao_clube: CompeticaoSituacaoClube;
  situacao_clube_fase: string | null;
  situacao_clube_data: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface CompeticaoBaseComTemporadaRow extends CompeticaoBaseRow {
  temporada: Pick<TemporadaBaseRow, "id" | "nome"> | null;
}

export interface CompeticaoFaseBaseRow {
  id: string;
  competicao_id: string;
  nome: string;
  ordem: number;
  status: CompeticaoFaseStatus;
  zerar_cartoes_ao_encerrar: boolean;
  criterios_desempate: string[] | null;
  created_at: string;
}

export interface CompeticaoGrupoBaseRow {
  id: string;
  fase_id: string;
  nome: string;
  ordem: number;
  created_at: string;
}

export interface CompeticaoGrupoEquipeBaseRow {
  id: string;
  grupo_id: string;
  nome: string | null;
  origem_grupo_id: string | null;
  origem_posicao: number | null;
  ordem: number;
  created_at: string;
}

/** Vínculo do jogo EXISTENTE (`public.jogos_base`) com competição/fase/grupo. */
export interface CompeticaoJogoBaseRow {
  id: string;
  competicao_id: string;
  jogo_id: string;
  fase_id: string | null;
  grupo_id: string | null;
  cartoes_amarelos_adversario: number;
  cartoes_vermelhos_adversario: number;
  sumula_link: string | null;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoGrupoResultadoBaseRow {
  id: string;
  grupo_id: string;
  equipe_casa: string;
  equipe_fora: string;
  gols_casa: number;
  gols_fora: number;
  data_jogo: string | null;
  rodada: string | null;
  sumula_path: string | null;
  cartoes_amarelos_casa: number;
  cartoes_amarelos_fora: number;
  cartoes_vermelhos_casa: number;
  cartoes_vermelhos_fora: number;
  sumula_link: string | null;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoInscricaoBaseRow {
  id: string;
  competicao_id: string;
  atleta_id: string;
  lista: CompeticaoListaInscricao | null;
  data_inscricao: string;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoSuspensaoManualBaseRow {
  id: string;
  competicao_id: string;
  atleta_id: string;
  origem: CompeticaoSuspensaoOrigem;
  motivo: string;
  jogos_suspensao: number;
  data_decisao: string;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoPrazoBaseRow {
  id: string;
  competicao_id: string;
  titulo: string;
  data_inicio: string | null;
  data_fim: string;
  concluido: boolean;
  created_by: string | null;
  created_at: string;
}

export interface CompeticaoDocumentoBaseRow {
  id: string;
  competicao_id: string;
  nome: string;
  arquivo_path: string;
  created_by: string | null;
  created_at: string;
}

// ===== Termo de Responsabilidade — Retirada de Materiais =====
// Ver docs/superpowers/specs/2026-08-11-termos-retirada-design.md.

export type TermoRetiradaTipo = "emprestimo" | "definitiva";

/** Documento assinado no ato da retirada de material do clube. Diferente de `estoque_saidas`
 * (catálogo do Estoque, com baixa de quantidade): aqui os itens são digitados livremente. */
export interface TermoRetiradaRow {
  id: string;
  numero: number;
  data: string;
  tipo: TermoRetiradaTipo;
  responsavel_nome: string;
  responsavel_documento: string | null;
  funcao: string | null;
  departamento: string | null;
  finalidade: string | null;
  /** Só faz sentido em empréstimo. */
  previsao_devolucao: string | null;
  /** Texto efetivamente assinado — gravado no termo pra o PDF de um documento antigo não mudar
   * quando o texto padrão do sistema for ajustado. */
  texto_responsabilidade: string;
  observacoes: string | null;
  devolvido_em: string | null;
  devolucao_observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TermoRetiradaItemRow {
  id: string;
  termo_id: string;
  descricao: string;
  quantidade: number;
  /** "Valor sugerido" do item — opcional; sustenta o trecho de ressarcimento do termo. */
  valor_unitario: number | null;
  ordem: number;
  created_at: string;
}

/** Tipo do anexo do termo: o documento assinado da retirada, o comprovante assinado da devolução,
 * ou qualquer outro arquivo de apoio (foto do material, nota fiscal). */
export type TermoRetiradaAnexoTipo = "assinado" | "devolucao" | "outro";

export interface TermoRetiradaAnexoRow {
  id: string;
  termo_id: string;
  tipo: TermoRetiradaAnexoTipo;
  nome: string;
  arquivo_path: string;
  created_by: string | null;
  created_at: string;
}

// ===== Hotéis (cadastro reutilizável — ver supabase/migrations/0070_hoteis.sql) =====

export interface HotelRow {
  id: string;
  nome: string;
  cnpj: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  cep: string | null;
  telefone: string | null;
  whatsapp: string | null;
  email: string | null;
  site: string | null;
  /** Pessoa de contato no hotel (comercial/eventos) — é com quem a reserva é fechada. */
  contato_nome: string | null;
  contato_funcao: string | null;
  contato_telefone: string | null;
  contato_email: string | null;
  diaria_referencia: number | null;
  cafe_incluso: boolean;
  estacionamento_onibus: boolean;
  sala_refeicao_grupo: boolean;
  horario_checkin: string | null;
  horario_checkout: string | null;
  observacoes: string | null;
  ativo: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

// ===== Veículos / Placas (ver supabase/migrations/0071_veiculos.sql) =====

/** Mesmos três grupos de pessoa do rooming list — o vínculo é opcional (condutor pode ser
 * terceirizado, familiar, dirigente convidado). */
export type VeiculoPessoaTipo = "atleta" | "comissao" | "staff";

export interface VeiculoRow {
  id: string;
  /** Condutor/responsável — é o nome impresso no ofício de liberação de acesso. */
  nome: string;
  documento: string | null;
  placa: string;
  modelo: string | null;
  marca: string | null;
  cor: string | null;
  ano: number | null;
  pessoa_tipo: VeiculoPessoaTipo | null;
  pessoa_id: string | null;
  telefone: string | null;
  observacoes: string | null;
  ativo: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

// ===== Vagas de Staff por jogo (ver supabase/migrations/0073_vagas_staff_jogo.sql) =====

/** Abertura de vagas de um jogo. `token` é o que vai na URL pública `/vagas/<token>`. */
export interface JogoVagasStaffRow {
  id: string;
  jogo_id: string;
  token: string;
  aberto: boolean;
  horario_apresentacao: string | null;
  local_apresentacao: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Uma função aberta e quantas vagas ela tem. A função vem do catálogo já usado pelo cadastro de
 * Staff Operacional — é o que permite cruzar a demanda do jogo com o que cada pessoa faz. */
export interface JogoVagasStaffFuncaoRow {
  id: string;
  vagas_id: string;
  funcao_id: string;
  quantidade: number;
  horario_apresentacao: string | null;
  created_at: string;
}

export type VagaStaffSituacao = "confirmado" | "espera";

export interface JogoVagasStaffInscricaoRow {
  id: string;
  vagas_id: string;
  vaga_funcao_id: string;
  staff_id: string;
  situacao: VagaStaffSituacao;
  observacao: string | null;
  /** Ordem de chegada — é o critério de tudo neste módulo. */
  created_at: string;
}

// ===== Vagas de Staff por jogo — FUTEBOL DE BASE (ver 0075_vagas_staff_base.sql) =====
// Espelham as três de cima, mas apontam para `jogos_base` e `staff_operacional_base`.

/** Abertura de vagas de um jogo da Base. `token` é o que vai na URL pública `/vagas-base/<token>`. */
export interface JogoVagasStaffBaseRow {
  id: string;
  jogo_id: string;
  token: string;
  aberto: boolean;
  horario_apresentacao: string | null;
  local_apresentacao: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface JogoVagasStaffBaseFuncaoRow {
  id: string;
  vagas_id: string;
  funcao_id: string;
  quantidade: number;
  horario_apresentacao: string | null;
  created_at: string;
}

export interface JogoVagasStaffBaseInscricaoRow {
  id: string;
  vagas_id: string;
  vaga_funcao_id: string;
  staff_id: string;
  situacao: VagaStaffSituacao;
  observacao: string | null;
  created_at: string;
}

// ===== Captação/Avaliação, Alojamento e cadastro de Atleta público — FUTEBOL DE BASE
// (ver 0076_captacao_alojamento_base.sql e docs/superpowers/specs/2026-08-19-captacao-base-design.md) =====

/** "inscricao" é a fila de quem se inscreveu pelo link público, esperando o Mateus aprovar e
 * informar a Data de Início (aba "Aprovações" — ver docs/superpowers/specs/
 * 2026-08-19-captacao-atletas-separacao-design.md). Dali em diante segue pros mesmos 4 status de
 * sempre — a Captação não cria mais nada em `atletas_base`, é um banco totalmente separado. */
export type CaptacaoStatus = "inscricao" | "avaliacao" | "aprovado" | "dispensado" | "nao_compareceu";

/** Um candidato em teste/avaliação — banco TOTALMENTE separado de `atletas_base` (ajuste de 19/08:
 * a Captação não cria mais cadastro de Atleta nenhum). `atleta_gerado_id` é só um resquício
 * histórico do fluxo antigo (ver 0076) — nenhuma tela lê ou grava mais essa coluna. */
export interface CaptacaoBaseRow {
  id: string;
  /** Nº sequencial gerado pelo banco — é o que a listagem mostra como "Nº". */
  numero: number;
  /** Só preenchida quando o status sai de "inscricao" — quem chega pelo link público de inscrição
   * ainda não tem uma data de início até o Mateus aprovar (ver `aprovarInscricaoCaptacao`). */
  data_inicio: string | null;
  /** Preenchida junto do resultado final (Aprovado/Dispensado/Não compareceu — ver
   * `mudarStatusCaptacao`). Volta a null se a avaliação for reaberta. */
  data_termino: string | null;
  nome_completo: string;
  data_nascimento: string | null;
  posicao: string | null;
  categoria: CategoriaBase | null;
  indicacao: string | null;
  deseja_alojamento: boolean;
  status: CaptacaoStatus;
  observacoes: string | null;
  telefone: string | null;
  mae_nome: string | null;
  mae_telefone: string | null;
  pai_nome: string | null;
  pai_telefone: string | null;
  empresario_nome: string | null;
  empresario_telefone: string | null;
  agencia: string | null;
  valor_ajuda_custo: number | null;
  escola: string | null;
  cep: string | null;
  logradouro: string | null;
  /** Número do endereço — nome diferente de `numero` (que já é o Nº sequencial do candidato) de
   * propósito, pra não colidir os dois campos. */
  numero_endereco: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  origem: "interno" | "publico";
  /** Reativada pela feature de auto-cadastro (ver spec 2026-09-11-captacao-documentos-termo-
   * auto-cadastro-design.md, seção 4) — volta a ser gravada quando o Treinador aprova o parecer.
   * Aponta pro id em `atletas_base`, não em `atletas` (Profissional). */
  atleta_gerado_id: string | null;
  /** Caminho no bucket `entity-photos` (mesmo padrão de `atletas_base.foto_path`). Upload feito
   * pelo staff na tela interna, e agora também pelo próprio candidato no link público de
   * inscrição (ver spec do Parecer Final e seção 2 do spec de 2026-09-11). */
  foto_path: string | null;
  clube_anterior: string | null;
  /** As 4 notas do Parecer Final, preenchidas pelo Treinador — sempre entre 3 e 9 (mesma escala da
   * legenda do documento: 3-4 Regular, 5-6 Bom, 7-8 Muito Bom, 9 Excelente). */
  nota_tecnica: number | null;
  nota_fisica: number | null;
  nota_tatica: number | null;
  nota_comportamental: number | null;
  parecer_comentarios: string | null;
  parecer_preenchido_em: string | null;
  parecer_preenchido_por: string | null;
  /** Campos novos pra cobrir a "Ficha de Avaliação" física (ver spec 2026-09-11, seção 1) — RG/CPF
   * do candidato, 2ª posição, pé dominante, altura/peso, e-mail, plano de saúde, escolaridade/
   * período escolar e federação. Todos opcionais no cadastro interno (`CaptacaoForm`), mas
   * obrigatórios na inscrição pública (`captacaoInscricaoSchema`). */
  rg: string | null;
  cpf: string | null;
  segunda_posicao: string | null;
  pe_dominante: "destro" | "canhoto" | "ambidestro" | null;
  /** Metros, ex. 1.75. */
  altura: number | null;
  /** Kg, ex. 68.5. */
  peso: number | null;
  email: string | null;
  possui_plano_saude: boolean | null;
  plano_saude_qual: string | null;
  escolaridade: string | null;
  periodo_escolar: "manha" | "tarde" | "noite" | null;
  federado: boolean | null;
  federado_clube: string | null;
  /** Termo de Responsabilidade — consentimento digital (ver spec 2026-09-11, seção 3). Não é uma
   * assinatura desenhada/ICP-Brasil, é um registro de aceite (nome + CPF do responsável legal, e
   * um "Li e concordo" separado do Atleta e do Responsável). */
  responsavel_legal_nome: string | null;
  responsavel_legal_cpf: string | null;
  termo_aceite_atleta: boolean;
  termo_aceite_responsavel: boolean;
  termo_aceito_em: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Um dos 5 documentos obrigatórios da inscrição de Captação (ver spec 2026-09-11, seção 2) — RG do
 * atleta, RG do(s) responsável(is), declaração escolar, atestado médico e eletrocardiograma com
 * laudo. Diferente de `atleta_documentos` (nome livre, lista aberta): aqui a lista é fixa, então
 * `tipo` é um enum fechado e cada tipo só aparece uma vez por candidato (reenviar substitui). A
 * foto do candidato NÃO é um `CaptacaoDocumentoRow` — continua em `CaptacaoBaseRow.foto_path`. */
export type CaptacaoDocumentoTipo =
  | "rg_atleta"
  | "rg_responsavel"
  | "declaracao_escolar"
  | "atestado_medico"
  | "eletrocardiograma";

export interface CaptacaoDocumentoRow {
  id: string;
  captacao_id: string;
  tipo: CaptacaoDocumentoTipo;
  /** Caminho no bucket `captacao-documentos`: `<captacao_id>/<tipo>.<ext>`. */
  arquivo_path: string;
  created_at: string;
}

/** Toggle da "Ficha de Cadastro" pública (`/cadastro-atleta-base`) — cria/atualiza direto em
 * `atletas_base` desde o ajuste de 19/08. Mesmo formato de `ConfiguracaoCadastroStaffBaseRow`,
 * tabela singleton própria. */
export interface ConfiguracaoCadastroAtletaBaseRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/** Toggle do link público de INSCRIÇÃO da Captação (`/inscricao-captacao-base`) — totalmente
 * separado do toggle acima (que é da Ficha de Cadastro de Atletas). */
export interface ConfiguracaoInscricaoCaptacaoBaseRow {
  id: string;
  cadastro_publico_ativo: boolean;
  updated_at: string;
}

/** Uma linha de assinatura do Parecer Final (nome + cargo) — ver `AssinaturaCaptacao` abaixo.
 * `id` é uma chave estável (não muda se a linha for reordenada) usada como
 * `assinaturas_documento.papel` quando essa linha assina digitalmente; `usuarioId` vincula a linha
 * a um login do sistema (ver docs/superpowers/specs/2026-08-28-assinatura-digital-notificacoes-
 * design.md, Fase 2) — `null`/ausente = ninguém vinculado ainda, qualquer "master" pode assinar. */
export interface AssinaturaCaptacao {
  id: string;
  nome: string;
  cargo: string;
  usuarioId?: string | null;
  /** Marca essa linha como sendo do Treinador responsável pela avaliação — em vez de vincular uma
   * pessoa fixa (varia por categoria), essa linha assina sozinha com quem de fato enviou o parecer
   * (`salvarParecerCaptacao`, ver docs/superpowers/specs/2026-08-28-assinatura-digital-
   * notificacoes-design.md), no mesmo instante do envio. Não aparece pra ninguém assinar manualmente
   * (nem master cai no fallback aqui — não faria sentido "qualquer master" assinar como Treinador). */
  ehTreinador?: boolean;
}

/** Configuração das assinaturas do Parecer Final de Avaliação (`/base/captacao/[id]/parecer/pdf`) —
 * singleton, mesmo espírito dos outros toggles/configurações de Captação. `assinaturas` é uma
 * lista (não colunas fixas tipo assinatura1/assinatura2 do Financeiro) porque o Mateus pediu "3 e
 * se precisar adiciono mais" — ver docs/superpowers/specs/2026-08-19-parecer-final-treinador-design.md. */
export interface ConfiguracaoParecerCaptacaoBaseRow {
  id: string;
  assinaturas: AssinaturaCaptacao[];
  updated_at: string;
}

/** Capacidade total do alojamento (singleton) — quem está alojado vem de `atletas_base.alojado`,
 * não desta tabela (ver lib/futebol/alojamento.ts). */
export interface AlojamentoBaseConfigRow {
  id: string;
  capacidade_total: number;
  observacoes: string | null;
  updated_at: string;
}

/** Turno de uma atividade da Programação Semanal — derivado de `horario_inicio` ao salvar, mas
 * guardado explícito pra não recalcular toda hora ao montar a grade. */
export type ProgramacaoTurno = "manha" | "tarde" | "noite";

/** Tipo de uma atividade da Programação Semanal do treinador — ver `lib/programacao/`. Distinto de
 * `ProgramacaoTipo` (que é dos pôsteres de Concentração/Dia de Jogo, um conceito não relacionado). */
export type ProgramacaoAtividadeTipo =
  | "programacao"
  | "refeicao"
  | "academia"
  | "treinamento"
  | "transporte"
  | "jogo_oficial"
  | "jogo_treino"
  | "imprensa"
  | "regenerativo"
  | "apresentacao"
  | "cafe_manha"
  | "video";

/** Área do Treinador — Programação Semanal (ver
 * docs/superpowers/specs/2026-08-30-area-treinador-programacao-design.md). Uma linha por atividade
 * do dia (treino, refeição, transporte, jogo etc.), por categoria. */
export interface ProgramacaoAtividadeRow {
  id: string;
  categoria: CategoriaBase;
  data: string;
  turno: ProgramacaoTurno;
  nome: string;
  tipo: ProgramacaoAtividadeTipo;
  horario_inicio: string;
  horario_termino: string | null;
  local: string | null;
  /** Só preenchido quando `tipo` é `jogo_oficial`/`jogo_treino` contra um jogo já cadastrado —
   * horário/local/adversário/escudo são sempre lidos de `JogoBaseRow` via este id, nunca duplicados
   * aqui (ver spec, "Atividade de jogo não duplica dado"). */
  jogo_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Subatividade dentro de uma `ProgramacaoAtividadeRow` (ex.: um bloco de treino técnico dentro do
 * treino da tarde). `config` guarda os campos ainda não normalizados do formulário (diagrama de
 * campo, regras, dimensões, orientações por posição, sliders físico/tático/técnico/comportamental,
 * métodos de treinamento) — ver spec, "Por que config jsonb". */
export interface ProgramacaoSubatividadeRow {
  id: string;
  atividade_id: string;
  nome: string;
  duracao_blocos: number | null;
  intervalo_min: number | null;
  video_url: string | null;
  observacoes: string | null;
  config: Record<string, unknown>;
  created_by: string | null;
  created_at: string;
}

/** Catálogo de subatividades reutilizáveis, por categoria (não por treinador, não global) —
 * escolher um item no dropdown "Importar" só copia os valores pra pré-preencher o formulário; não
 * cria vínculo com a subatividade salva depois (ver spec, "Catálogo não é modificado ao ser
 * usado"). Mesmo formato de `ProgramacaoSubatividadeRow`, sem `atividade_id`. */
export interface ProgramacaoCatalogoSubatividadeRow {
  id: string;
  categoria: CategoriaBase;
  nome: string;
  duracao_blocos: number | null;
  intervalo_min: number | null;
  video_url: string | null;
  observacoes: string | null;
  config: Record<string, unknown>;
  created_by: string | null;
  created_at: string;
}

/** Época e número do microciclo por categoria, usados só na exportação do microciclo em PDF/JPG —
 * o Mateus incrementa `microciclo_atual` manualmente a cada semana, do jeito que já faz hoje em
 * Excel. Singleton por categoria (uma linha por categoria, sempre pré-criada). */
export interface ConfiguracaoProgramacaoBaseRow {
  categoria: CategoriaBase;
  epoca: string | null;
  microciclo_atual: number;
  /** Substitui o número fixo "Microciclo Nº X" no cabeçalho da exportação por uma descrição livre,
   * a critério do treinador (ex.: "Semana de adaptação") — ver spec, "Microciclo em texto livre".
   * `microciclo_atual` continua existindo sem mudança, só deixou de ser usado na exportação. */
  microciclo_texto: string | null;
  updated_at: string;
}

// ===== Departamento Médico — sub-área Fisioterapia (Futebol Profissional) — ver docs/superpowers/
// specs/2026-09-30-fisioterapia-design.md =====

/** Classificação clínica única, compartilhada por Lesões e Queixas — ver migração 0116. Reproduz
 * as 6 categorias do relatório em papel do departamento (Relatorio_Fisioterapia_2.pdf), não mais
 * o antigo "muscular"/"articular" genérico (que só existia em Queixas e não correspondia ao que o
 * Mateus realmente usa — ex.: "Tendinite patelar joelho" é DOR TENDÍNEA/FASCIAL, não articular). */
export type FisioterapiaTipo =
  | "muscular"
  | "articular"
  | "tendinea_fascial"
  | "ligamentar"
  | "osseo"
  | "trauma";

/** Uma lesão formal, com afastamento. "Dias afastados" nunca é gravado — sempre calculado a partir
 * de `data_inicio`/`data_fim` (ver `lib/futebol/fisioterapia.ts`). `data_fim` vazio = lesão ainda
 * ativa (e é o que decide `atletas.status`, ver a mesma lib). `data_inicio` nulo só ocorre em
 * registros trazidos do histórico importado (relatório em papel, sem data exata) — a tela nunca
 * deixa lançar uma lesão nova sem data. */
export interface FisioterapiaLesaoRow {
  id: string;
  atleta_id: string;
  descricao: string;
  tipo: FisioterapiaTipo;
  data_inicio: string | null;
  data_fim: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Queixa pontual, sem afastamento — mais leve que uma lesão formal. `data` nula só ocorre em
 * registros trazidos do histórico importado (ver `FisioterapiaLesaoRow`). */
export interface FisioterapiaQueixaRow {
  id: string;
  atleta_id: string;
  tipo: FisioterapiaTipo;
  data: string | null;
  descricao: string;
  created_by: string | null;
  created_at: string;
}

/** Classificação do atendimento do dia (ver docs/superpowers/specs/
 * 2026-10-07-relatorio-dia-fisioterapia-design.md) — opcional, independente do `atletas.status`
 * "oficial" (Apto/Depto. Médico/Transição, ver `AtletaStatus`): essa aqui é só uma etiqueta
 * informativa de como o atendimento daquele dia correu, pro Relatório do Dia. */
export type FisioterapiaStatusDia = "manutencao" | "tratamento" | "reavaliacao";

/** Uma sessão de fisioterapia — solta (ex.: sessão preventiva) ou ligada a uma lesão em andamento
 * via `lesao_id`. `data` nula só ocorre em registros trazidos do histórico importado (ver
 * `FisioterapiaLesaoRow`); nesse caso `quantidade` guarda quantos atendimentos aquele registro
 * único representa (ex.: 57) — nulo em qualquer atendimento normal, lançado pela tela, que vale 1.
 * `status_dia` é opcional e nulo em todo atendimento lançado antes de 07/10/2026. */
export interface FisioterapiaAtendimentoRow {
  id: string;
  atleta_id: string;
  lesao_id: string | null;
  data: string | null;
  descricao: string;
  quantidade: number | null;
  status_dia: FisioterapiaStatusDia | null;
  created_by: string | null;
  created_at: string;
}

/** Uma linha da linha do tempo de status do atleta (ver docs/superpowers/specs/
 * 2026-10-01-departamento-medico-historico-status-design.md) — lançada automaticamente (abrir/
 * fechar lesão) ou manualmente (tela "Histórico de Status"). `criado_por_nome` é um retrato (não
 * muda se a pessoa renomear a conta depois), igual `assinaturas_documento`. */
export interface AtletaStatusHistoricoRow {
  id: string;
  atleta_id: string;
  status: AtletaStatus;
  data: string;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Linha do tempo de ativo/inativo do atleta (ver docs/superpowers/specs/2026-11-04-atletas-
 * desativacao-transicao-pagamento-design.md) — eixo independente de `AtletaStatusHistoricoRow`
 * (aquele é liberado/departamento médico/transição/dispensado; este é só ativo/inativo). `motivo`
 * só é preenchido ao desativar (null na reativação); `observacao` é opcional na desativação e
 * obrigatória na reativação. */
export interface AtletaAtivoHistoricoRow {
  id: string;
  atleta_id: string;
  ativo: boolean;
  motivo: string | null;
  observacao: string | null;
  data: string;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

// ===== Fisioterapia do Futebol de Base (ver docs/superpowers/specs/
// 2026-10-06-fisioterapia-base-design.md) — espelha as 4 interfaces acima, ligadas a
// `atletas_base(id)` em vez de `atletas(id)`. Mesmo `FisioterapiaTipo` dos dois lados (vocabulário
// de tipo de lesão/queixa não muda entre departamentos). Diferente do Profissional, `data_inicio`/
// `data`/`data_fim` já nascem opcionais (sem histórico importado pra exigir isso depois).

export interface FisioterapiaLesaoBaseRow {
  id: string;
  atleta_id: string;
  descricao: string;
  tipo: FisioterapiaTipo;
  data_inicio: string | null;
  data_fim: string | null;
  observacoes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface FisioterapiaQueixaBaseRow {
  id: string;
  atleta_id: string;
  tipo: FisioterapiaTipo;
  data: string | null;
  descricao: string;
  created_by: string | null;
  created_at: string;
}

export interface FisioterapiaAtendimentoBaseRow {
  id: string;
  atleta_id: string;
  lesao_id: string | null;
  data: string | null;
  descricao: string;
  quantidade: number | null;
  status_dia: FisioterapiaStatusDia | null;
  created_by: string | null;
  created_at: string;
}

/** Linha do tempo de status do atleta da Base — espelha `AtletaStatusHistoricoRow`, mas com os 4
 * valores de `AtletaBaseStatus` (inclui "suspenso"/"dispensado", que não existem no Profissional).
 * A sincronização automática (abrir/fechar lesão) só alterna entre "departamento_medico" e
 * "liberado" — as outras duas entram só por lançamento manual. */
export interface AtletaBaseStatusHistoricoRow {
  id: string;
  atleta_id: string;
  status: AtletaBaseStatus;
  data: string;
  criado_por_perfil_id: string | null;
  criado_por_nome: string | null;
  created_at: string;
}

/** Resumo em texto livre de um período ANTES da existência deste módulo — não é uma lesão/queixa/
 * atendimento estruturada (ver docs/superpowers/specs/2026-09-30-fisioterapia-design.md e a
 * migração 0112). Existe porque o relatório em papel que o Mateus já tinha (ex.: Copa Paulista
 * 2026) só registrava totais e listas de queixas em texto, sem data exata de cada evento — em vez
 * de fabricar datas, esse histórico entra como referência. `atleta_id` nulo = resumo GERAL do
 * período (agregados do departamento), usado no Relatório Geral. Dados novos sempre entram pelas 3
 * tabelas estruturadas acima. */
export interface FisioterapiaHistoricoImportadoRow {
  id: string;
  atleta_id: string | null;
  titulo: string;
  resumo: string;
  created_by: string | null;
  created_at: string;
}

/** Um atendimento do módulo Assistência Social (Futebol de Base) — ver docs/superpowers/specs/
 * 2026-10-05-assistencia-social-e-demandas-design.md, Parte 1. `encaminhamento` é opcional: nem
 * todo atendimento gera um encaminhamento. */
export interface AssistenciaSocialAtendimentoRow {
  id: string;
  atleta_id: string;
  data: string;
  anotacoes: string;
  encaminhamento: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

/** Status possíveis de uma Demanda — ver `DemandaRow` abaixo. Sem "solicitado" (diferente de
 * `TarefaStatus`) — esse valor só fazia sentido no fluxo de Tarefas. */
export type DemandaStatus = "pendente" | "em_andamento" | "concluido";

/** Uma demanda/pendência de uma pessoa acompanhada no Painel de Demandas — ver docs/superpowers/
 * specs/2026-10-05-assistencia-social-e-demandas-design.md, Parte 2. `responsavel_id` é sempre
 * quem está logado ao criar (nunca recebido de outra pessoa) — cada um mexe só nas próprias. */
export interface DemandaRow {
  id: string;
  titulo: string;
  descricao: string | null;
  prazo: string | null;
  status: DemandaStatus;
  responsavel_id: string;
  created_at: string;
  updated_at: string;
}
