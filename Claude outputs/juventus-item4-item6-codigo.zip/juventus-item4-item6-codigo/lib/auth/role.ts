import * as React from "react";
import { createClient as criarClientePadrao, type createClient } from "@/lib/supabase/server";
import type { PerfilRole } from "@/lib/supabase/types";

// `React.cache` só existe na versão de "react" que o Next.js usa por baixo dos panos pra
// Server Components (o `react` 18.3 instalado como dependência comum não exporta isso) — nos
// testes (vitest, fora do pipeline de build do Next) `React.cache` vem `undefined`. Em vez de
// quebrar a suíte de teste inteira por causa disso, cai pra uma versão sem cache nenhum (chama a
// função direto, toda vez) quando `cache` não existir — só perde a otimização de deduplicar a
// query por request, não quebra nada.
const cache: <T extends (...args: never[]) => unknown>(fn: T) => T =
  typeof React.cache === "function" ? React.cache : (fn) => fn;
import { TODOS_MODULOS, type ModuloChave } from "@/lib/auth/modulos";
import { TODOS_MODULOS_BASE, type ModuloBaseChave } from "@/lib/auth/modulos-base";
import { TODOS_DEPARTAMENTOS, type DepartamentoChave } from "@/lib/auth/departamentos";
import { TODAS_TAREFA_CATEGORIAS } from "@/lib/auth/tarefas-categorias";
import { TODAS_ESTOQUE_CATEGORIAS } from "@/lib/auth/estoque-categorias";
import {
  TODAS_CATEGORIAS_BASE,
  ehCategoriaBaseValida,
  type CategoriaBase,
  type CategoriaComissaoTecnica,
} from "@/lib/auth/categorias-base";
import type { CampoSensivel } from "@/lib/auth/campos-sensiveis";

export interface PerfilPermissoes {
  role: PerfilRole;
  modulos_permitidos: string[] | null;
  modulos_base_permitidos: string[] | null;
  departamentos_permitidos: string[] | null;
  tarefas_categorias_visiveis: string[] | null;
  estoque_categorias_permitidas: string[] | null;
  categorias_treinador: string[] | null;
  comissao_tecnica_id: string | null;
  categorias_base_permitidas: string[] | null;
  /** Embed do PostgREST — só vem preenchido quando `comissao_tecnica_id` aponta pra um registro
   * existente (ver docs/superpowers/specs/2026-09-13-acesso-por-categoria-comissao-tecnica-
   * design.md). Resolvido no mesmo round-trip da query de `buscarPerfilPermissoes`, sem query
   * adicional nem quebra da memoização por request. `funcao` foi acrescentado ao embed em
   * docs/superpowers/specs/2026-10-27-assinatura-financeiro-base-por-supervisor-design.md, pra
   * decidir quem é Supervisor sem precisar de outra query. Desde a unificação da Comissão Técnica
   * (ver docs/superpowers/specs/2026-10-28-unificacao-comissao-tecnica-design.md), `categorias`
   * pode incluir "profissional" junto das categorias da Base — as funções abaixo que são
   * específicas da Base (`resolverCategoriasBasePermitidas`, `resolverEhSupervisorDaCategoriaBase`)
   * filtram/ignoram esse valor, sem mudar de comportamento. */
  comissao_tecnica: { categorias: CategoriaComissaoTecnica[]; funcao: string } | null;
  /** Sub-área Fisioterapia do módulo Departamento Médico — ver
   * docs/superpowers/specs/2026-09-30-fisioterapia-design.md e `getFisioterapiaPodeEditar` abaixo. */
  fisioterapia_pode_editar: boolean | null;
  /** Mesma ideia, pro Departamento Médico do Futebol de Base — ver docs/superpowers/specs/
   * 2026-10-06-fisioterapia-base-design.md e `getFisioterapiaPodeEditarBase` abaixo. */
  fisioterapia_pode_editar_base: boolean | null;
  /** Campos sensíveis (ex.: salário) escondidos desta pessoa mesmo com o módulo liberado — ver
   * docs/superpowers/specs/2026-10-02-campos-sensiveis-e-atletas-por-categoria-design.md e
   * `getCamposSensiveisBloqueados`/`podeVerCampoSensivel` abaixo. */
  campos_sensiveis_bloqueados: string[] | null;
  /** Aparece no Painel de Demandas do master e no widget "Minhas Demandas" da tela inicial — ver
   * docs/superpowers/specs/2026-10-05-assistencia-social-e-demandas-design.md, Parte 2, e
   * `getDemandasAcompanhado` abaixo. */
  demandas_acompanhado: boolean | null;
  /** Pode usar a ação "Transitar atleta" pra trocar a categoria de qualquer atleta (Base ou
   * Profissional) — ver docs/superpowers/specs/2026-11-04-atletas-desativacao-transicao-pagamento-
   * design.md e `getPodeTransitarCategoriaAtleta` abaixo. */
  pode_transitar_categoria_atleta: boolean | null;
}

/** Uma única leitura de `perfis` com tudo que as funções abaixo precisam — evita repetir a mesma
 * query quando mais de uma checagem é feita na mesma página. Exportada pra módulos que precisam
 * combinar mais de um campo de uma vez (ex.: `lib/programacao/permissoes.ts`) sem repetir a
 * query uma vez por campo.
 *
 * A busca de verdade (`buscarPerfilPermissoes` abaixo) é memoizada por request com `cache()` do
 * React — o AppShell, o middleware^ e a própria página muitas vezes checam permissão mais de uma
 * vez na mesma navegação (cada `get*Permitidos`/`isMaster`/`getCategoriasProgramacao` chama isto
 * por baixo), e sem memoizar isso vira uma query em `perfis` repetida 4-5x por carregamento de
 * tela — parte do que deixava o sistema "lento em geral" (ver auditoria de performance de
 * 01/09/2026). Por isso ignoramos de propósito o `supabase` recebido aqui e criamos um cliente
 * novo por dentro: `cache()` do React só deduplica quando os argumentos são os mesmos, e cada
 * Server Component que chama `createClient()` ganha uma instância nova — usar sempre a mesma
 * função sem argumento (que lê os cookies da request, iguais em qualquer client criado durante o
 * mesmo request) é o que faz a deduplicação funcionar de verdade.
 * ^ (o middleware roda em Edge, fora do escopo de `cache()` do React — lá a otimização é outra,
 * ver o comentário em `lib/supabase/middleware.ts`.)
 */
export async function getPerfilPermissoes(
  _supabase: ReturnType<typeof createClient>,
): Promise<PerfilPermissoes | null> {
  return buscarPerfilPermissoes();
}

const buscarPerfilPermissoes = cache(async (): Promise<PerfilPermissoes | null> => {
  const supabase = criarClientePadrao();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("perfis")
    .select(
      "role, modulos_permitidos, modulos_base_permitidos, departamentos_permitidos, " +
        "tarefas_categorias_visiveis, estoque_categorias_permitidas, categorias_treinador, " +
        "comissao_tecnica_id, categorias_base_permitidas, " +
        "fisioterapia_pode_editar, fisioterapia_pode_editar_base, campos_sensiveis_bloqueados, " +
        "demandas_acompanhado, pode_transitar_categoria_atleta, " +
        "comissao_tecnica:comissao_tecnica_id(categorias, funcao)",
    )
    .eq("id", user.id)
    .maybeSingle();

  return data as unknown as PerfilPermissoes | null;
});

/**
 * Papel do usuário atualmente logado. Se não estiver logado, ou não tiver uma linha em `perfis`
 * por algum motivo (não deveria acontecer em uso normal), trata como "regular" — nunca assume
 * "master" por padrão, já que essa checagem é o que decide quem pode excluir Entrada/Saída do
 * Estoque e acessar /usuarios.
 */
export async function getUserRole(supabase: ReturnType<typeof createClient>): Promise<PerfilRole> {
  const perfil = await getPerfilPermissoes(supabase);
  return perfil?.role ?? "regular";
}

export async function isMaster(supabase: ReturnType<typeof createClient>): Promise<boolean> {
  return (await getUserRole(supabase)) === "master";
}

/**
 * Categorias que o Treinador logado pode ver/agir na Captação — vazio se não estiver logado, ou
 * se o papel não for "treinador" (evita um "regular" acidentalmente cair em telas de Treinador só
 * porque `categorias_treinador` ficou preenchida de um uso anterior do perfil). Ver
 * docs/superpowers/specs/2026-08-19-parecer-final-treinador-design.md.
 */
export async function getCategoriasTreinador(
  supabase: ReturnType<typeof createClient>,
): Promise<string[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil || perfil.role !== "treinador") return [];
  return perfil.categorias_treinador ?? [];
}

/**
 * Departamentos (Futebol Profissional / Futebol de Base) que o usuário logado pode ver/acessar.
 * "Master" sempre tem os dois. Usado pra filtrar os cartões da tela inicial (`app/page.tsx`) — a
 * checagem que de fato bloqueia o acesso é a do middleware.
 */
export async function getDepartamentosPermitidos(
  supabase: ReturnType<typeof createClient>,
): Promise<DepartamentoChave[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return [];
  if (perfil.role === "master") return TODOS_DEPARTAMENTOS;
  return (perfil.departamentos_permitidos ?? TODOS_DEPARTAMENTOS) as DepartamentoChave[];
}

/**
 * Módulos que o usuário logado pode ver/acessar dentro do Futebol Profissional. "Master" sempre
 * tem todos, independente do que está salvo em `modulos_permitidos` (mesma regra do middleware,
 * ver `lib/supabase/middleware.ts`). Quem não tem o departamento "futebol_profissional" liberado
 * não tem nenhum módulo, independente de `modulos_permitidos` — todos os módulos de hoje são desse
 * departamento. Usado pra filtrar os cartões da Home do departamento (`app/profissional/page.tsx`)
 * e o menu superior (`components/app-shell.tsx`).
 */
export async function getModulosPermitidos(
  supabase: ReturnType<typeof createClient>,
): Promise<ModuloChave[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return [];
  if (perfil.role === "master") return TODOS_MODULOS;

  const departamentos = perfil.departamentos_permitidos ?? TODOS_DEPARTAMENTOS;
  if (!departamentos.includes("futebol_profissional")) return [];

  return (perfil.modulos_permitidos ?? TODOS_MODULOS) as ModuloChave[];
}

/**
 * Módulos que o usuário logado pode ver/acessar dentro do Futebol de Base. Espelha
 * `getModulosPermitidos()`: "master" sempre tem todos; quem não tem o departamento
 * "futebol_base" liberado não tem nenhum módulo de Base, independente do que está salvo em
 * `modulos_base_permitidos`. Usado pra filtrar os cartões da Home do departamento
 * (`app/base/page.tsx`) e o menu superior (`components/app-shell.tsx`).
 */
export async function getModulosBasePermitidos(
  supabase: ReturnType<typeof createClient>,
): Promise<ModuloBaseChave[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return [];
  if (perfil.role === "master") return TODOS_MODULOS_BASE;

  const departamentos = perfil.departamentos_permitidos ?? TODOS_DEPARTAMENTOS;
  if (!departamentos.includes("futebol_base")) return [];

  return (perfil.modulos_base_permitidos ?? TODOS_MODULOS_BASE) as ModuloBaseChave[];
}

/**
 * Categorias de Tarefas (Logística, Registro, Financeiro, Solicitações, Gerais) que aparecem como
 * aba em `/tarefas` pra esse usuário. É só preferência de exibição — a lista de tarefas continua
 * compartilhada entre todo mundo, isto não bloqueia nada, só filtra o que aparece (ver
 * `lib/auth/tarefas-categorias.ts`).
 */
export async function getCategoriasTarefasVisiveis(
  supabase: ReturnType<typeof createClient>,
): Promise<string[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return TODAS_TAREFA_CATEGORIAS;
  return perfil.tarefas_categorias_visiveis ?? TODAS_TAREFA_CATEGORIAS;
}

/**
 * Ramificações do módulo Estoque (Esportivo / Medicamentos / Materiais) que o usuário logado pode acessar. Ao
 * contrário de `getCategoriasTarefasVisiveis`, isto É uma permissão de acesso de verdade — quem
 * não tiver uma delas aqui não entra em `/estoque/<categoria>` (ver
 * `lib/supabase/middleware.ts`). "Master" sempre tem as duas.
 */
export async function getEstoqueCategoriasPermitidas(
  supabase: ReturnType<typeof createClient>,
): Promise<string[]> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return [];
  if (perfil.role === "master") return TODAS_ESTOQUE_CATEGORIAS;
  return perfil.estoque_categorias_permitidas ?? TODAS_ESTOQUE_CATEGORIAS;
}

/**
 * Regra de categorias do Futebol de Base (Atletas, Jogos e tudo dentro de um jogo), separada da
 * leitura em `perfis` só pra poder ser testada sem precisar simular um client do Supabase (mesmo
 * raciocínio de `resolverCategoriasProgramacao` em `lib/programacao/permissoes.ts` — ver
 * `lib/auth/role.test.ts`). Ver docs/superpowers/specs/2026-09-13-acesso-por-categoria-comissao-
 * tecnica-design.md.
 *
 * "Master" sempre tem as 7; quem não tem o departamento "futebol_base" liberado não tem nenhuma.
 * Quando a conta está vinculada a alguém da Comissão Técnica (`comissao_tecnica_id`) e esse
 * registro tem pelo menos uma categoria da Base entre as dele, as categorias vêm AO VIVO de lá
 * (editar a pessoa muda o acesso na hora, sem precisar mexer no login) — só cai no fallback manual
 * (`categorias_base_permitidas`) sem vínculo, ou com um vínculo que não tem nenhuma categoria da
 * Base (ex.: vinculado só a um registro "profissional"; não deveria acontecer em uso normal pra
 * quem usa esta função, mas evita zerar o acesso por engano).
 */
export function resolverCategoriasBasePermitidas(perfil: PerfilPermissoes | null): CategoriaBase[] {
  if (!perfil) return [];
  if (perfil.role === "master") return TODAS_CATEGORIAS_BASE;

  const departamentos = perfil.departamentos_permitidos ?? TODOS_DEPARTAMENTOS;
  if (!departamentos.includes("futebol_base")) return [];

  if (perfil.comissao_tecnica_id && perfil.comissao_tecnica) {
    const categoriasBase = perfil.comissao_tecnica.categorias.filter(ehCategoriaBaseValida);
    if (categoriasBase.length > 0) return categoriasBase;
  }
  return (perfil.categorias_base_permitidas ?? TODAS_CATEGORIAS_BASE) as CategoriaBase[];
}

/** Versão de `resolverCategoriasBasePermitidas` que já busca o perfil do usuário logado — usada
 * pelas páginas/guards de verdade. */
export async function getCategoriasBasePermitidas(
  supabase: ReturnType<typeof createClient>,
): Promise<CategoriaBase[]> {
  const perfil = await getPerfilPermissoes(supabase);
  return resolverCategoriasBasePermitidas(perfil);
}

/**
 * Se o usuário logado pode assinar a Assinatura 1 ("Supervisor de Futebol de Base") do Orçamento
 * Previsto/Relatório de Despesas de um jogo de uma categoria específica — ver
 * docs/superpowers/specs/2026-10-27-assinatura-financeiro-base-por-supervisor-design.md. "Master"
 * sempre pode, mesmo com um Supervisor certo já vinculado àquela categoria (reserva, ex.: o
 * Supervisor está de férias). Sem vínculo com a Comissão Técnica da Base, nunca pode — ao
 * contrário de `resolverCategoriasBasePermitidas`, aqui não existe fallback manual: o objetivo é
 * justamente não deixar o Supervisor de uma categoria assinar o jogo de outra (ou alguém que não é
 * Supervisor assinar qualquer jogo). Com vínculo, só pode se a função cadastrada contiver
 * "supervisor" (comparação sem diferenciar maiúsculas/minúsculas, cobre variações como "Supervisor
 * de Futebol de Base") e a categoria do jogo estiver entre as categorias cadastradas dela.
 */
export function resolverEhSupervisorDaCategoriaBase(
  perfil: PerfilPermissoes | null,
  categoria: CategoriaBase,
): boolean {
  if (!perfil) return false;
  if (perfil.role === "master") return true;
  if (!perfil.comissao_tecnica_id || !perfil.comissao_tecnica) return false;

  const { funcao, categorias } = perfil.comissao_tecnica;
  if (!funcao.toLowerCase().includes("supervisor")) return false;
  return categorias.includes(categoria);
}

/** Versão de `resolverEhSupervisorDaCategoriaBase` que já busca o perfil do usuário logado — usada
 * pela tela de Financeiro de jogo da Base. */
export async function ehSupervisorDaCategoriaBase(
  supabase: ReturnType<typeof createClient>,
  categoria: CategoriaBase,
): Promise<boolean> {
  const perfil = await getPerfilPermissoes(supabase);
  return resolverEhSupervisorDaCategoriaBase(perfil, categoria);
}

/**
 * Pode inserir/editar registros da sub-área Fisioterapia (Departamento Médico) — ver
 * docs/superpowers/specs/2026-09-30-fisioterapia-design.md, seção 1. "Master" sempre pode, sem
 * exceção (regra geral do sistema); "regular" só quando `fisioterapia_pode_editar` está marcado
 * pra ele (é o fisioterapeuta) — os demais com o módulo liberado só visualizam. Quem não está
 * logado, ou não tem o módulo liberado (não é checado aqui — isso é papel do middleware), continua
 * recebendo `false`. Toda rota de gravação (as `actions.ts` de `app/departamento-medico/fisioterapia`)
 * chama isto no servidor antes de escrever, nunca confiando só no formulário estar oculto no client.
 */
export async function getFisioterapiaPodeEditar(
  supabase: ReturnType<typeof createClient>,
): Promise<boolean> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return false;
  if (perfil.role === "master") return true;
  return perfil.fisioterapia_pode_editar ?? false;
}

/** Mesma ideia de `getFisioterapiaPodeEditar`, pro Departamento Médico do Futebol de Base —
 * permissão própria, independente da do Profissional (ver docs/superpowers/specs/
 * 2026-10-06-fisioterapia-base-design.md: normalmente é outra pessoa cuidando da Base). */
export async function getFisioterapiaPodeEditarBase(
  supabase: ReturnType<typeof createClient>,
): Promise<boolean> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return false;
  if (perfil.role === "master") return true;
  return perfil.fisioterapia_pode_editar_base ?? false;
}

/**
 * Pode usar a ação "Transitar atleta" (ver docs/superpowers/specs/2026-11-04-atletas-
 * desativacao-transicao-pagamento-design.md) — muda a categoria de QUALQUER atleta (Base ou
 * Profissional), inclusive fora de `categorias_base_permitidas`/`departamentos_permitidos` dessa
 * pessoa (acesso "emprestado" deliberado, só pra esta ação). "Master" sempre pode, mesmo padrão de
 * `getFisioterapiaPodeEditar`. Checar sempre no servidor (nunca confiar só em esconder o botão no
 * client) — mesmo princípio de `salvarParecerCaptacao`/`salvarRelatorioDispensaTreinador`.
 */
export async function getPodeTransitarCategoriaAtleta(
  supabase: ReturnType<typeof createClient>,
): Promise<boolean> {
  const perfil = await getPerfilPermissoes(supabase);
  if (!perfil) return false;
  if (perfil.role === "master") return true;
  return perfil.pode_transitar_categoria_atleta ?? false;
}

/**
 * Se a transição de `categoriaAtual` pra `novaCategoria` cruza a fronteira Futebol de
 * Base/Profissional (uma das duas é "profissional" e a outra é uma das 7 categorias de Base, ou
 * vice-versa). Decisão do Mateus em 14/11/2026: não existe (e não vai existir) um perfil "Gerente
 * do Profissional" — cada responsável de categoria já transita atletas dentro do que enxerga
 * normalmente (`pode_transitar_categoria_atleta`, ver acima, que inclusive empresta acesso entre
 * categorias da própria Base ou dentro do Profissional); só cruzar a fronteira Base↔Profissional
 * fica reservado ao "master", já que ninguém mais acessa os dois departamentos ao mesmo tempo. Ver
 * `transitarCategoriaAtleta` em app/atletas/actions.ts, que chama isto além de
 * `getPodeTransitarCategoriaAtleta`.
 */
export function cruzaFronteiraBaseProfissional(categoriaAtual: string, novaCategoria: string): boolean {
  return ehCategoriaBaseValida(categoriaAtual) !== ehCategoriaBaseValida(novaCategoria);
}

/**
 * Se o usuário logado pode ver a Área Financeira (`/area-financeira`) — papel "financeiro" (ver
 * docs/superpowers/specs/2026-10-22-area-financeira-design.md) ou "master" (que sempre pode
 * acessar qualquer área do sistema). Qualquer outro papel recebe `false` — as páginas da Área
 * Financeira usam isto pra decidir se mostram os dados de verdade ou um aviso de acesso negado,
 * mesmo que a pessoa digite a URL direto (mesmo raciocínio de `getCategoriasTreinador`, que zera
 * os dados pra quem não é o papel certo em vez de confiar só no middleware).
 */
export async function podeVerAreaFinanceira(
  supabase: ReturnType<typeof createClient>,
): Promise<boolean> {
  const role = await getUserRole(supabase);
  return role === "financeiro" || role === "master";
}

/**
 * Se o usuário logado aparece no Painel de Demandas do master e ganha o widget "Minhas Demandas"
 * na tela inicial/sidebar — ver docs/superpowers/specs/2026-10-05-assistencia-social-e-demandas-
 * design.md, Parte 2. Diferente de `getFisioterapiaPodeEditar`, não existe bypass pra "master" aqui:
 * isto não é uma permissão de acesso (a tela `/minhas-demandas` funciona pra qualquer um logado,
 * marcado ou não), é só quem o Mateus decidiu acompanhar — inclusive ele mesmo, se quiser.
 */
export async function getDemandasAcompanhado(
  supabase: ReturnType<typeof createClient>,
): Promise<boolean> {
  const perfil = await getPerfilPermissoes(supabase);
  return perfil?.demandas_acompanhado ?? false;
}

/**
 * Campos sensíveis (catálogo em `lib/auth/campos-sensiveis.ts`, hoje só "salario") escondidos
 * deste perfil, mesmo que ele tenha o módulo liberado — ver docs/superpowers/specs/2026-10-02-
 * campos-sensiveis-e-atletas-por-categoria-design.md. "Master" nunca tem nada escondido, qualquer
 * que seja o valor gravado em `perfis` (nem a opção aparece pra ele em `/usuarios`). Sem perfil
 * (deslogado), também nada escondido — quem decide se a pessoa pode ou não acessar a tela em
 * primeiro lugar é o middleware/módulo, não esta função.
 */
export function resolverCamposSensiveisBloqueados(perfil: PerfilPermissoes | null): CampoSensivel[] {
  if (!perfil || perfil.role === "master") return [];
  return (perfil.campos_sensiveis_bloqueados ?? []) as CampoSensivel[];
}

/** Versão de `resolverCamposSensiveisBloqueados` que já busca o perfil do usuário logado — usada
 * pelas páginas/actions de verdade. */
export async function getCamposSensiveisBloqueados(
  supabase: ReturnType<typeof createClient>,
): Promise<CampoSensivel[]> {
  const perfil = await getPerfilPermissoes(supabase);
  return resolverCamposSensiveisBloqueados(perfil);
}

/** Atalho pra checar um campo sensível específico — `!bloqueados.includes(campo)`, mas evita
 * repetir esse `!includes` em todo lugar que precisa checar só um campo. */
export async function podeVerCampoSensivel(
  supabase: ReturnType<typeof createClient>,
  campo: CampoSensivel,
): Promise<boolean> {
  const bloqueados = await getCamposSensiveisBloqueados(supabase);
  return !bloqueados.includes(campo);
}
